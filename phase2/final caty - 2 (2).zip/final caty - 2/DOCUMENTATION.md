# Catalyst Timetable Management System — Technical Documentation

**Version:** 3.0 (Production Release — Milestones 1–4C)  
**Target Environment:** C++17, Qt 6.12.0 (Widgets, Sql), MySQL 8.0 (Native / ODBC Driver), CMake 3.21+, MinGW 64-bit (GCC 13.1.0)  
**Workspace:** `d:/final caty - 2`

---

## Table of Contents
1. [System Architecture Overview](#1-system-architecture-overview)
2. [Database Schema & Relational Architecture](#2-database-schema--relational-architecture)
3. [Constraint Satisfaction (CSP) Generation Engine](#3-constraint-satisfaction-csp-generation-engine)
4. [Timetable Quality Optimization & Penalty Formulation](#4-timetable-quality-optimization--penalty-formulation)
5. [Automated Section Editing & Differential Assignment Management](#5-automated-section-editing--differential-assignment-management)
6. [Admin Portal UI & Section Timetable View](#6-admin-portal-ui--section-timetable-view)
7. [Automated Verification & CLI Test Runner Suite](#7-automated-verification--cli-test-runner-suite)
8. [Configuration, Build & Troubleshooting Guide](#8-configuration-build--troubleshooting-guide)

---

## 1. System Architecture Overview

Catalyst is an automated academic scheduling and timetable management application. It decouples high-performance constraint programming from database persistence and Qt graphical interfaces through a modular four-layer architecture:

```mermaid
flowchart TD
    subgraph UI_Layer [Presentation Layer - Qt 6 Widgets]
        AdminPortal["AdminPortal<br>• Master Timetable View<br>• Section Timetable (Weekly Grid)<br>• Section & Assignment Management"]
        SectionDlg["SectionAssignmentDialog<br>• Dynamic Course Curriculum<br>• Teacher Eligibility Filtering<br>• Timetable Invalidation Feedback"]
        FacultyPortal["FacultyPortal<br>• Teacher-specific filtered views"]
    end

    subgraph Service_Layer [Application Service Layer]
        TTS["TimetableService<br>• Live DB Requirement Loading<br>• Instance Expansion & Lab Bridging<br>• Independent Verification<br>• Atomic Transaction Persistence"]
    end

    subgraph CSP_Engine [CSP Scheduling & Optimization Engine]
        TG["TimetableGenerator<br>• Backtracking Solver<br>• MRV Variable Selection<br>• Multi-Objective LCV Penalty Scoring<br>• Bounded Solution Search (Target Penalty)"]
        CV["ConflictValidator<br>• O(1) Occupancy Hash Sets<br>• Hard Constraint Enforcement<br>• Room Capacity & Type Compatibility"]
        Models["SchedulingModels<br>• LectureRequirement<br>• LectureInstance<br>• Allocation / SchedulingState"]
    end

    subgraph DB_Layer [Data Access Layer - MySQL 8.0]
        DBM["DatabaseManager (Singleton)<br>• QSqlDatabase (QODBC / QMYSQL)<br>• Differential Assignment Engine<br>• ACID Transactions with Rollback<br>• Prepared Statements"]
        MySQL[("MySQL catalyst_db<br>10 Relational Tables")]
    end

    UI_Layer --> Service_Layer
    UI_Layer --> DBM
    Service_Layer --> CSP_Engine
    Service_Layer --> DBM
    CSP_Engine --> Models
    DBM --> MySQL
```

### Core Architectural Principles
- **Zero Algorithmic DB Dependencies:** The CSP engine (`TimetableGenerator`, `ConflictValidator`) contains pure standard C++17 without Qt SQL headers or raw queries. It receives plain DTOs and outputs structured in-memory allocations.
- **Dynamic Cataloging:** No IDs, room sizes, or section counts are hardcoded. The application queries all active curricula, faculty qualifications, and section requirements dynamically from MySQL.
- **Strict ACID Transactions:** Schedule generation, replacement, and section updates execute within atomic SQL transactions. If any check fails, the transaction is immediately rolled back, leaving the database unmodified.
- **Fail-First Early Pruning:** Variables are sorted via Minimum Remaining Values (MRV) and forward checked so unsolvable branches are abandoned immediately before deeper recursion.

---

## 2. Database Schema & Relational Architecture

The relational database `catalyst_db` contains 10 normalized tables enforcing foreign key constraints and composite business rules:

```mermaid
erDiagram
    course ||--o{ section : "has"
    course ||--o{ coursesubject : "curriculum"
    subject ||--o{ coursesubject : "in"
    subject ||--o{ teachersubject : "qualified"
    teacher ||--o{ teachersubject : "teaches"
    
    section ||--o{ sectionsubjectteacher : "assigned"
    subject ||--o{ sectionsubjectteacher : "assigned"
    teachersubject ||--o{ sectionsubjectteacher : "enforces eligibility"

    section ||--o{ timetableentry : "scheduled for"
    subject ||--o{ timetableentry : "scheduled"
    teacher ||--o{ timetableentry : "conducted by"
    room ||--o{ timetableentry : "located in"
    timeslot ||--o{ timetableentry : "at day & slot"
```

### Table Definitions & Primary Constraints

1. **`course`**:
   - `course_id` (INT, PK, AUTO_INCREMENT), `course_name` (VARCHAR).
2. **`section`**:
   - `section_id` (INT, PK, AUTO_INCREMENT), `section_name` (VARCHAR), `course_id` (FK -> `course`), `student_count` (INT, CHECK > 0).
   - `UNIQUE KEY (section_name, course_id)`.
3. **`subject`**:
   - `subject_id` (INT, PK, AUTO_INCREMENT), `subject_name` (VARCHAR, UNIQUE), `lectures_per_week` (INT), `subject_type` (ENUM: `'lecture'`, `'lab'`).
4. **`teacher`**:
   - `teacher_id` (INT, PK, AUTO_INCREMENT), `name` (VARCHAR), `email` (VARCHAR).
5. **`room`**:
   - `room_id` (INT, PK, AUTO_INCREMENT), `room_name` (VARCHAR, UNIQUE), `capacity` (INT), `room_type` (ENUM: `'classroom'`, `'lab'`).
6. **`timeslot`**:
   - `day` (TINYINT: 0=Mon, 1=Tue, 2=Wed, 3=Thu, 4=Fri), `slot_index` (TINYINT: 0..6), `start_time` (TIME), `end_time` (TIME), `is_break` (BOOLEAN).
   - `PRIMARY KEY (day, slot_index)`.
7. **`coursesubject`**:
   - Maps subjects to degree curricula. `PRIMARY KEY (course_id, subject_id)`.
8. **`teachersubject`**:
   - Authorizes faculty eligibility. `PRIMARY KEY (teacher_id, subject_id)`.
9. **`sectionsubjectteacher`**:
   - Active subject-teacher assignments per cohort.
   - `PRIMARY KEY (section_id, subject_id)`.
   - `UNIQUE KEY (section_id, subject_id, teacher_id)`.
   - `FOREIGN KEY (teacher_id, subject_id) REFERENCES teachersubject (teacher_id, subject_id)`.
10. **`timetableentry`**:
    - Final scheduled allocations.
    - `PRIMARY KEY (entry_id)`.
    - `UNIQUE KEY (teacher_id, day, slot_index)` — prevents faculty double-booking.
    - `UNIQUE KEY (room_id, day, slot_index)` — prevents room double-booking.
    - `UNIQUE KEY (section_id, day, slot_index)` — prevents section double-booking.
    - `FOREIGN KEY (section_id, subject_id, teacher_id) REFERENCES sectionsubjectteacher (section_id, subject_id, teacher_id)`.

---

## 3. Constraint Satisfaction (CSP) Generation Engine

### CSP Formalization
- **Variables ($X$)**: Set of expanded lecture instances $X_i \in \{x_1, x_2, \dots, x_N\}$, where each instance represents 1 hour of theory or 2 continuous hours of lab.
- **Domain ($D_i$)**: Combinations of valid starting timeslots and compatible rooms:
  $$D_i = \{(t, r) \mid t \in \text{TimeSlots}, r \in \text{Rooms}\}$$
- **Hard Constraints ($C$)**:
  1. *Section Clash-Free:* No section has $>1$ lecture in slot $s \in [t, t + \text{dur}-1]$.
  2. *Faculty Clash-Free:* No faculty teaches $>1$ section in slot $s \in [t, t + \text{dur}-1]$.
  3. *Room Clash-Free:* No room hosts $>1$ class in slot $s \in [t, t + \text{dur}-1]$.
  4. *Break Integrity:* Neither single-hour classes nor 2-hour labs may occupy or cross lunch break (`slot_index = 3`).
  5. *Day Boundary:* A 2-hour lab cannot start at the final slot of the day (`slot_index = 6`).
  6. *Room Type Compatibility:* Theory instances $\to$ `RoomType::Classroom`; Lab instances $\to$ `RoomType::Lab`.
  7. *Room Capacity:* `room.capacity >= section.studentCount`.

### Core CSP Algorithms

#### 1. Minimum Remaining Values (MRV) Variable Selection
At each search level, the solver evaluates the size of the feasible domain $|D_i|$ for all unassigned variables. The variable with the smallest domain is chosen first:
$$x^* = \arg\min_{x_i \in \text{Unassigned}} |D_i|$$
- **Tie-Breaking (Degree Heuristic):** If multiple variables have identical domain sizes, the variable with the highest degree (larger cohort size and multi-slot duration) is scheduled first.
- **Fail-First Pruning:** If $|D_i| = 0$ for any unassigned variable, the branch is recognized as infeasible immediately without exploring sub-trees.

#### 2. ConflictValidator ($O(1)$ Bitwise Hash Sets)
`ConflictValidator` maintains fast integer-keyed hash tables for state occupancy:
- `m_teacherOccupancy`: `teacherId * 1000 + day * 100 + slot`
- `m_sectionOccupancy`: `sectionId * 1000 + day * 100 + slot`
- `m_roomOccupancy`: `roomId * 1000 + day * 100 + slot`

All checks (`isTeacherFree`, `isSectionFree`, `isRoomFree`) run in $O(1)$ worst-case time.

---

## 4. Timetable Quality Optimization & Penalty Formulation

In earlier versions, the solver accepted the first mathematically feasible solution, resulting in Monday starvation (only 1 entry) and teachers having 3 consecutive periods of the same subject on Tuesday/Wednesday. 

Catalyst 3.0 integrates **Multi-Objective Candidate Penalty Scoring** in LCV ordering combined with **Bounded Search Exploration**:

### Heuristic Candidate Penalty Formula
In `TimetableGenerator::calculateCandidatePenalty(...)`, each valid `(slot, room)` candidate is scored:

$$\text{Penalty}(c) = P_{\text{rep}} + P_{\text{cons}} + P_{\text{bal}} + P_{\text{room}} + P_{\text{gap}} - \text{LCV}_{\text{tie}}$$

1. **Same-Subject Daily Repetition Penalty ($P_{\text{rep}}$)**:
   - For theory classes: If section already has $k$ classes of this subject on this day, add $+2000 \times k$.
   - **Result:** Guarantees at most 1 theory lecture per subject per day for each section.
2. **Teacher Consecutive Period Protection ($P_{\text{cons}}$)**:
   - Evaluates adjacent teaching slots ($s - 1, s + \text{dur}$).
   - If allocating candidate creates $\ge 3$ consecutive occupied slots for that faculty member, add $+2500$.
   - **Result:** 100% elimination of 3-period faculty burnout runs across all sections.
3. **Section Daily Workload Balance ($P_{\text{bal}}$)**:
   - Underutilized Day Bonus: If section has 0 classes on this day (e.g. Monday), award **-120 bonus**.
   - Heavy Load Penalty: If section already has $\ge 4$ classes on this day, add $+250$.
   - Faculty Day Spread: Add $+150 \times \text{classes today}$.
   - **Result:** Monday–Friday entries distributed evenly across the week.
4. **Classroom Continuity ($P_{\text{room}}$)**:
   - If section is taught in the adjacent previous or next period in the same room, award **-90 bonus**.
   - If section moves to a different classroom for an adjacent lecture, add $+80$.
   - **Result:** Eliminates unnecessary room hopping between consecutive periods.
5. **Schedule Continuity ($P_{\text{gap}}$)**:
   - Award **-35 bonus** if class touches an existing section period (avoids stranding isolated 1-hour sessions).

### Bounded Solution Search (`solve`)
Configured in `GeneratorConfig`:
- `enableOptimization = true`
- `targetQualityPenalty = 500`
- `maxSolutionsToExplore = 15`

The solver iterates through candidates sorted by lowest penalty, evaluates the global schedule penalty using `evaluateSchedulePenalty(...)`, retains the best state found (`bestState`), and terminates as soon as the quality penalty drops below the threshold.

---

## 5. Automated Section Editing & Differential Assignment Management

### The Foreign Key Challenge
Editing a section's assigned faculty previously failed with MySQL Error 1451:
`Cannot delete or update a parent row: a foreign key constraint fails (catalyst_db.timetableentry, CONSTRAINT timetableentry_ibfk_1)`

This occurred because `timetableentry` enforces referential integrity on `sectionsubjectteacher (section_id, subject_id, teacher_id)`.

### Differential Assignment Transaction Pipeline
Catalyst 3.0 implements `DatabaseManager::saveSectionWithAssignments(...)` using a differential, dependency-aware transaction:

1. **Eligibility Verification**:
   Validates every `(teacherId, subjectId)` pair against `teachersubject`. Ineligible faculty assignments are rejected with descriptive messages before database operations.
2. **Differential Comparison**:
   Queries current assignments and compares them against submitted assignments:
   - `toRemove`: In existing, absent in new.
   - `toUpdate`: Present in both, but `teacher_id` modified.
   - `toAdd`: Absent in existing, present in new.
   - `unchanged`: Both `subject_id` and `teacher_id` identical.
3. **Targeted Timetable Invalidation**:
   - If `assignmentsChanged` is true and timetable entries exist for this section:
     ```sql
     DELETE FROM timetableentry WHERE section_id = :sec_id;
     ```
   - Sets `*outTimetableInvalidated = true`.
   - **All other sections' timetable records remain 100% untouched.**
   - If assignments are **unchanged** (e.g. only section name or student count updated), the timetable is preserved.
4. **Selective Update**:
   - `DELETE FROM sectionsubjectteacher` for `toRemove`.
   - `UPDATE sectionsubjectteacher SET teacher_id = :t_id` for `toUpdate`.
   - `INSERT INTO sectionsubjectteacher` for `toAdd`.
   - `unchanged` assignments are not touched.
5. **Atomic Commit & Rollback**:
   Executes within an atomic transaction. Any query failure triggers immediate `db.rollback()`.

---

## 6. Admin Portal UI & Section Timetable View

The Admin Portal provides intuitive views for timetable oversight and operational control:

```
+-----------------------------------------------------------------------------------------------------+
| Catalyst Admin Portal                                                     [Generate Timetable Button] |
+-----------------------------------------------------------------------------------------------------+
| [Master Timetable] [Section Timetable] [Faculty] [Sections] [Courses] [Subjects] [Rooms] [Timeslots]|
+-----------------------------------------------------------------------------------------------------+
| Section: [ Section D (B.Tech CSE)  v ]     Showing 20 scheduled class periods for Section D.        |
|                                                                                                     |
| Day / Slot | Slot 1 (09-10) | Slot 2 (10-11) | Slot 3 (11-12) | Lunch Break | Slot 4 (13-14) | ...  |
| -----------+----------------+----------------+----------------+-------------+----------------+----- |
| Monday     | DBMS (CS-201)  | DS (CS-201)    | OOP (CS-201)   | Lunch Break | OS (CS-201)    | Free |
| Tuesday    | DBMS (CS-202)  | DS (CS-202)    | OS (CS-202)    | Lunch Break | Free           | ...  |
| Wednesday  | OOP (CS-201)   | [LAB] DS Lab (Lab-2)            | Lunch Break | OS (CS-201)    | Free |
| Thursday   | Maths (CS-202) | Free           | Free           | Lunch Break | DS (CS-201)    | ...  |
| Friday     | DS (CS-202)    | DBMS (CS-201)  | OOP (CS-202)   | Lunch Break | Free           | ...  |
+-----------------------------------------------------------------------------------------------------+
```

### Key UI Capabilities
- **Section Timetable View**: Displays full weekly schedules in a grid dynamically constructed from `timeslot` records.
- **Visual Lab Span Merging**: 2-slot consecutive lab sessions are visually merged into single cohesive blocks via `QTableWidget::setSpan(r, c, 1, 2)`.
- **Intelligent Feedback**: When section edits invalidate an existing timetable, a clear modal warning notifies the administrator that the timetable for that specific section must be regenerated.
- **Safe Generation Trigger**: The "Generate Timetable" action checks existing database records and prompts for explicit confirmation before replacing existing schedules.

---

## 7. Automated Verification & CLI Test Runner Suite

Catalyst provides built-in headless CLI test flags for continuous integration and operational diagnostics:

```powershell
# Set Qt & MinGW Environment
$env:PATH="D:\qt\6.12.0\mingw_64\bin;D:\qt\Tools\mingw1310_64\bin;$env:PATH"

# 1. Run ConflictValidator Edge & Hard Constraint Tests (30 tests)
.\build-qt\Catalyst.exe --test-validator

# 2. Run CSP Generator Backtracking & Heuristic Tests (29 tests)
.\build-qt\Catalyst.exe --test-generator

# 3. Run Live Database Service & Transaction Tests (18 tests)
.\build-qt\Catalyst.exe --test-service

# 4. Run AdminPortal UI Workflow & Section Editing Tests (42 tests)
.\build-qt\Catalyst.exe --test-admin

# 5. Headless Production Timetable Generation & Commit
.\build-qt\Catalyst.exe --generate-timetable

# 6. Database Connectivity & Driver Diagnostic Check
.\build-qt\Catalyst.exe --test-db
```

### Test Suite Coverage Summary

| Test Flag | Test Harness | Total Assertions | Scope Verified |
| :--- | :--- | :---: | :--- |
| `--test-validator` | `ConflictValidatorTests.h` | **30 / 30 PASSED** | Clash detection, room types, lab continuity, break constraints, room capacity limits. |
| `--test-generator` | `TimetableGeneratorTests.h` | **29 / 29 PASSED** | MRV fail-first, backtracking search, 2-slot lab bridges, search limit bounds, multi-section solving. |
| `--test-service` | `TimetableServiceTests.h` | **18 / 18 PASSED** | Requirement loading, expansion, rollback on error, atomic SQL commit. |
| `--test-admin` | `AdminPortalTests.h` | **42 / 42 PASSED** | All 10 section-editing scenarios, timetable invalidation, differential update, UI table population. |

---

## 8. Configuration, Build & Troubleshooting Guide

### Prerequisites
- Qt 6.12.0 MinGW 64-bit (`libQt6Widgets`, `libQt6Sql`, `libQt6Gui`, `libQt6Core`)
- MinGW GCC 13.1.0 64-bit
- Ninja 1.10+
- MySQL Server 8.0 with `catalyst_db` initialized

### Database Configuration (`db_config.ini`)
Located in root project directory:
```ini
[database]
driver=auto
host=127.0.0.1
port=3306
database_name=catalyst_db
username=root
password=Sherdha@1628
odbc_driver=MySQL ODBC 26.7 Unicode Driver
```

### Build Instructions
```powershell
# Open PowerShell in workspace root
cd "d:\final caty - 2"

# Compile and link with Ninja
& "D:/qt/Tools/Ninja/ninja.exe" -C build-qt
```

### Common Troubleshooting

1. **`Permission Denied: Catalyst.exe` during linking**:
   - Occurs when an instance of `Catalyst.exe` is currently running.
   - Solution: Stop running processes (`Stop-Process -Name Catalyst -Force -ErrorAction SilentlyContinue`) or rename `build-qt\Catalyst.exe` to `build-qt\Catalyst.exe.old` and re-run Ninja.
2. **`QSqlDatabase: QMYSQL / QODBC driver not loaded`**:
   - Ensure `libqsqlmysql.dll` or `libqsqlodbc.dll` is present in `D:\qt\6.12.0\mingw_64\plugins\sqldrivers`.
   - Ensure MySQL client libraries are on the system PATH.
3. **Empty Section Timetable Grid**:
   - Verify that the section has active assignments in `sectionsubjectteacher` and timetable records in `timetableentry`.
   - Click "Generate Timetable" to populate entries.

