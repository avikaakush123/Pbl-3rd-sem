set(__QT_DEPLOY_TARGETS "Catalyst")
set(__QT_DEPLOY_TARGET_Catalyst_FILE D:/final caty - 2/build-qt/Catalyst.exe)
set(__QT_DEPLOY_TARGET_Catalyst_TYPE EXECUTABLE)
set(__QT_DEPLOY_TARGET_Catalyst_RUNTIME_DLLS D:/qt/6.12.0/mingw_64/bin/Qt6Widgets.dll;D:/qt/6.12.0/mingw_64/bin/Qt6Sql.dll;D:/qt/6.12.0/mingw_64/bin/Qt6Gui.dll;D:/qt/6.12.0/mingw_64/bin/Qt6Core.dll)
