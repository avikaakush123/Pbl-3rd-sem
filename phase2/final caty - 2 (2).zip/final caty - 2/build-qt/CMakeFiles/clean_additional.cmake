# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  "CMakeFiles\\Catalyst_autogen.dir\\AutogenUsed.txt"
  "CMakeFiles\\Catalyst_autogen.dir\\ParseCache.txt"
  "Catalyst_autogen"
  )
endif()
