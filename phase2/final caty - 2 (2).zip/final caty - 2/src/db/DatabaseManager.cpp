#include "DatabaseManager.h"
#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QProcessEnvironment>
#include <QSettings>
#include <QSqlRecord>

const QString DatabaseManager::CONNECTION_NAME = "CatalystDBConnection";

DatabaseManager &DatabaseManager::instance() {
  static DatabaseManager instance;
  return instance;
}

DatabaseManager::DatabaseManager() {}

DatabaseManager::~DatabaseManager() {
  // Only close and remove database if QCoreApplication is still alive
  if (QCoreApplication::instance()) {
    close();
  }
}

DatabaseManager::Config DatabaseManager::loadConfig() const {
  Config cfg;
  cfg.driver = "auto";

  cfg.host = "127.0.0.1";
  cfg.port = 3306;
  cfg.databaseName = "catalyst_db";
  cfg.username = "root";
  cfg.password = "";
  cfg.odbcDriver = "MySQL ODBC 8.0 Unicode Driver";

  QStringList candidatePaths = {
      QDir::current().filePath("db_config.ini"),
      QDir(QCoreApplication::applicationDirPath()).filePath("db_config.ini"),
      QDir(QCoreApplication::applicationDirPath()).filePath("../db_config.ini"),
      "D:/final caty/db_config.ini"};

  QString foundPath;
  for (const QString &path : candidatePaths) {
    if (QFile::exists(path)) {
      foundPath = path;
      break;
    }
  }

  if (!foundPath.isEmpty()) {
    QSettings settings(foundPath, QSettings::IniFormat);
    settings.beginGroup("database");
    cfg.driver = settings.value("driver", cfg.driver).toString().trimmed();
    cfg.host = settings.value("host", cfg.host).toString().trimmed();
    cfg.port = settings.value("port", cfg.port).toInt();
    cfg.databaseName =
        settings.value("database_name", cfg.databaseName).toString().trimmed();
    cfg.username =
        settings.value("username", cfg.username).toString().trimmed();
    cfg.password = settings.value("password", cfg.password).toString();
    cfg.odbcDriver =
        settings.value("odbc_driver", cfg.odbcDriver).toString().trimmed();
    settings.endGroup();
  }

  QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
  if (env.contains("DB_DRIVER"))
    cfg.driver = env.value("DB_DRIVER").trimmed();
  if (env.contains("DB_HOST"))
    cfg.host = env.value("DB_HOST").trimmed();
  if (env.contains("DB_PORT")) {
    bool ok = false;
    int p = env.value("DB_PORT").toInt(&ok);
    if (ok && p > 0)
      cfg.port = p;
  }
  if (env.contains("DB_NAME"))
    cfg.databaseName = env.value("DB_NAME").trimmed();
  if (env.contains("DB_USER"))
    cfg.username = env.value("DB_USER").trimmed();
  if (env.contains("DB_PASS"))
    cfg.password = env.value("DB_PASS");
  if (env.contains("ODBC_DRIVER_NAME"))
    cfg.odbcDriver = env.value("ODBC_DRIVER_NAME").trimmed();

  return cfg;
}

QString
DatabaseManager::resolveOdbcDriver(const QString &configuredDriver) const {
  if (!configuredDriver.isEmpty()) {
    return configuredDriver;
  }
  return "MySQL ODBC 8.0 Unicode Driver";
}

bool DatabaseManager::connect(QString *errorOut) {
  if (!QCoreApplication::instance()) {
    if (errorOut)
      *errorOut = "Cannot connect: QCoreApplication is not initialized.";
    return false;
  }

  Config cfg = loadConfig();
  QStringList availableDrivers = QSqlDatabase::drivers();

  QString selectedDriver = cfg.driver;
  if (selectedDriver.compare("auto", Qt::CaseInsensitive) == 0) {
    if (availableDrivers.contains("QMYSQL", Qt::CaseInsensitive)) {
      selectedDriver = "QMYSQL";
    } else if (availableDrivers.contains("QODBC", Qt::CaseInsensitive)) {
      selectedDriver = "QODBC";
    } else {
      QString err =
          QString("No compatible SQL driver found. Qt available drivers: [%1]. "
                  "Neither QMYSQL nor QODBC is present.")
              .arg(availableDrivers.join(", "));
      if (errorOut)
        *errorOut = err;
      qWarning().noquote() << err;
      return false;
    }
  }

  QSqlDatabase db;
  if (QSqlDatabase::contains(CONNECTION_NAME)) {
    db = QSqlDatabase::database(CONNECTION_NAME);
    if (db.isOpen() &&
        db.driverName().compare(selectedDriver, Qt::CaseInsensitive) == 0) {
      return true;
    }
    db.close();
    QSqlDatabase::removeDatabase(CONNECTION_NAME);
  }

  db = QSqlDatabase::addDatabase(selectedDriver, CONNECTION_NAME);

  if (selectedDriver.compare("QMYSQL", Qt::CaseInsensitive) == 0) {
    db.setHostName(cfg.host);
    db.setPort(cfg.port);
    db.setDatabaseName(cfg.databaseName);
    db.setUserName(cfg.username);
    db.setPassword(cfg.password);
  } else if (selectedDriver.compare("QODBC", Qt::CaseInsensitive) == 0) {
    QString odbcDriver = resolveOdbcDriver(cfg.odbcDriver);
    QString connStr =
        QString(
            "Driver={%1};Server=%2;Port=%3;Database=%4;Uid=%5;Pwd=%6;Option=3;")
            .arg(odbcDriver, cfg.host, QString::number(cfg.port),
                 cfg.databaseName, cfg.username, cfg.password);
    db.setDatabaseName(connStr);
  }

  if (!db.open()) {
    QSqlError lastErr = db.lastError();
    QString errText = lastErr.text().trimmed();
    if (errText.isEmpty()) {
      errText = "Unknown error opening database.";
    }

    QString detailed =
        QString(
            "Failed to connect using driver '%1' to database '%2' at %3:%4.\n"
            "Error: %5")
            .arg(selectedDriver, cfg.databaseName, cfg.host,
                 QString::number(cfg.port), errText);

    if (selectedDriver.compare("QODBC", Qt::CaseInsensitive) == 0 &&
        errText.contains("Data source name not found", Qt::CaseInsensitive)) {
      detailed += QString("\n\nHint: The ODBC driver '%1' was not found in "
                          "Windows ODBC Data Sources. "
                          "Make sure MySQL Connector/ODBC (64-bit) is "
                          "installed on your system.")
                      .arg(resolveOdbcDriver(cfg.odbcDriver));
    }

    if (errorOut)
      *errorOut = detailed;
    qWarning().noquote() << detailed;
    return false;
  }

  return true;
}

bool DatabaseManager::isConnected() const {
  if (!QCoreApplication::instance())
    return false;
  if (!QSqlDatabase::contains(CONNECTION_NAME))
    return false;
  QSqlDatabase db = QSqlDatabase::database(CONNECTION_NAME);
  return db.isOpen() && db.isValid();
}

void DatabaseManager::ensureConnected() {
  if (!isConnected()) {
    connect();
  }
}

void DatabaseManager::close() {
  if (!QCoreApplication::instance())
    return;
  if (QSqlDatabase::contains(CONNECTION_NAME)) {
    {
      QSqlDatabase db = QSqlDatabase::database(CONNECTION_NAME);
      if (db.isOpen()) {
        db.close();
      }
    }
    QSqlDatabase::removeDatabase(CONNECTION_NAME);
  }
}

QSqlDatabase DatabaseManager::getDatabase() const {
  if (QCoreApplication::instance() && QSqlDatabase::contains(CONNECTION_NAME)) {
    return QSqlDatabase::database(CONNECTION_NAME);
  }
  return QSqlDatabase();
}

int DatabaseManager::getTeacherCount() {
  ensureConnected();
  QSqlQuery q(getDatabase());
  if (q.exec("SELECT COUNT(*) FROM teacher") && q.next()) {
    return q.value(0).toInt();
  }
  return 0;
}

int DatabaseManager::getSectionCount() {
  ensureConnected();
  QSqlQuery q(getDatabase());
  if (q.exec("SELECT COUNT(*) FROM section") && q.next()) {
    return q.value(0).toInt();
  }
  return 0;
}

int DatabaseManager::getRoomCount() {
  ensureConnected();
  QSqlQuery q(getDatabase());
  if (q.exec("SELECT COUNT(*) FROM room") && q.next()) {
    return q.value(0).toInt();
  }
  return 0;
}

int DatabaseManager::getSubjectCount() {
  ensureConnected();
  QSqlQuery q(getDatabase());
  if (q.exec("SELECT COUNT(*) FROM subject") && q.next()) {
    return q.value(0).toInt();
  }
  return 0;
}

int DatabaseManager::getTimeslotCount() {
  ensureConnected();
  QSqlQuery q(getDatabase());
  if (q.exec("SELECT COUNT(*) FROM timeslot") && q.next()) {
    return q.value(0).toInt();
  }
  return 0;
}

int DatabaseManager::getTimetableEntryCount() {
  ensureConnected();
  QSqlQuery q(getDatabase());
  if (q.exec("SELECT COUNT(*) FROM timetableentry") && q.next()) {
    return q.value(0).toInt();
  }
  return 0;
}

QList<DatabaseManager::Teacher> DatabaseManager::getTeachers() {
  ensureConnected();
  QList<Teacher> list;
  QSqlQuery q(getDatabase());
  if (q.exec("SELECT teacher_id, name FROM teacher ORDER BY teacher_id ASC")) {
    while (q.next()) {
      Teacher t;
      t.id = q.value(0).toInt();
      t.name = q.value(1).toString();
      list.append(t);
    }
  }
  return list;
}

QList<DatabaseManager::Course> DatabaseManager::getCourses() {
  ensureConnected();
  QList<Course> list;
  QSqlQuery q(getDatabase());
  if (q.exec(
          "SELECT course_id, course_name FROM course ORDER BY course_id ASC")) {
    while (q.next()) {
      Course c;
      c.id = q.value(0).toInt();
      c.name = q.value(1).toString();
      list.append(c);
    }
  }
  return list;
}

QList<DatabaseManager::Section> DatabaseManager::getSections() {
  ensureConnected();
  QList<Section> list;
  QSqlQuery q(getDatabase());
  const QString sql = "SELECT s.section_id, s.section_name, s.course_id, "
                      "COALESCE(c.course_name, '-'), s.student_count "
                      "FROM section s "
                      "LEFT JOIN course c ON s.course_id = c.course_id "
                      "ORDER BY s.course_id ASC, s.section_name ASC";
  if (q.exec(sql)) {
    while (q.next()) {
      Section s;
      s.id = q.value(0).toInt();
      s.name = q.value(1).toString();
      s.courseId = q.value(2).toInt();
      s.courseName = q.value(3).toString();
      s.studentCount = q.value(4).toInt();
      list.append(s);
    }
  }
  return list;
}

QList<DatabaseManager::Subject> DatabaseManager::getSubjects() {
  ensureConnected();
  QList<Subject> list;
  QSqlQuery q(getDatabase());
  if (q.exec("SELECT subject_id, subject_name, lectures_per_week, subject_type "
             "FROM subject ORDER BY subject_id ASC")) {
    while (q.next()) {
      Subject sub;
      sub.id = q.value(0).toInt();
      sub.name = q.value(1).toString();
      sub.lecturesPerWeek = q.value(2).toInt();
      sub.type = q.value(3).toString();
      list.append(sub);
    }
  }
  return list;
}

QList<DatabaseManager::Room> DatabaseManager::getRooms() {
  ensureConnected();
  QList<Room> list;
  QSqlQuery q(getDatabase());
  if (q.exec("SELECT room_id, room_name, capacity, room_type FROM room ORDER "
             "BY room_id ASC")) {
    while (q.next()) {
      Room r;
      r.id = q.value(0).toInt();
      r.name = q.value(1).toString();
      r.capacity = q.value(2).toInt();
      r.type = q.value(3).toString();
      list.append(r);
    }
  }
  return list;
}

QList<DatabaseManager::Timeslot> DatabaseManager::getTimeslots(int day) {
  ensureConnected();
  QList<Timeslot> list;
  QSqlQuery q(getDatabase());
  QString sql = "SELECT slot_id, day, slot_index, "
                "DATE_FORMAT(start_time, '%H:%i'), DATE_FORMAT(end_time, "
                "'%H:%i'), is_break "
                "FROM timeslot ";
  if (day >= 0) {
    sql += QString("WHERE day = %1 ").arg(day);
  }
  sql += "ORDER BY day ASC, slot_index ASC";

  if (q.exec(sql)) {
    while (q.next()) {
      Timeslot ts;
      ts.id = q.value(0).toInt();
      ts.day = q.value(1).toInt();
      ts.slotIndex = q.value(2).toInt();
      ts.startTime = q.value(3).toString();
      ts.endTime = q.value(4).toString();
      ts.isBreak = q.value(5).toBool();
      list.append(ts);
    }
  }
  return list;
}

QList<DatabaseManager::TimetableEntry>
DatabaseManager::getFacultyTimetable(int teacherId, int day) {
  ensureConnected();
  QList<TimetableEntry> list;
  QSqlQuery q(getDatabase());
  QString sql =
      "SELECT "
      "te.entry_id, "
      "te.section_id, sec.section_name, c.course_name, "
      "te.subject_id, sub.subject_name, "
      "te.teacher_id, t.name, "
      "te.room_id, r.room_name, "
      "te.day, te.slot_index, "
      "CONCAT(DATE_FORMAT(ts.start_time, '%H:%i'), ' - ', "
      "DATE_FORMAT(ts.end_time, '%H:%i')) AS time_range "
      "FROM timetableentry te "
      "JOIN timeslot ts ON te.day = ts.day AND te.slot_index = ts.slot_index "
      "JOIN subject sub ON te.subject_id = sub.subject_id "
      "JOIN section sec ON te.section_id = sec.section_id "
      "JOIN course c ON sec.course_id = c.course_id "
      "JOIN room r ON te.room_id = r.room_id "
      "JOIN teacher t ON te.teacher_id = t.teacher_id "
      "WHERE te.teacher_id = :teacher_id ";
  if (day >= 0) {
    sql += QString("AND te.day = %1 ").arg(day);
  }
  sql += "ORDER BY te.day ASC, te.slot_index ASC";

  q.prepare(sql);
  q.bindValue(":teacher_id", teacherId);

  if (!q.exec()) {
    qWarning() << "getFacultyTimetable SQL failed:" << q.lastError().text()
               << "Query:" << sql;
  } else {
    while (q.next()) {
      TimetableEntry entry;
      entry.entryId = q.value(0).toInt();
      entry.sectionId = q.value(1).toInt();
      entry.sectionName = q.value(2).toString();
      entry.courseName = q.value(3).toString();
      entry.subjectId = q.value(4).toInt();
      entry.subjectName = q.value(5).toString();
      entry.teacherId = q.value(6).toInt();
      entry.teacherName = q.value(7).toString();
      entry.roomId = q.value(8).toInt();
      entry.roomName = q.value(9).toString();
      entry.day = q.value(10).toInt();
      entry.slotIndex = q.value(11).toInt();
      entry.timeRange = q.value(12).toString();
      list.append(entry);
    }
  }
  return list;
}

QList<DatabaseManager::TimetableEntry>
DatabaseManager::getSectionTimetable(int sectionId) {
  ensureConnected();
  QList<TimetableEntry> list;
  QSqlQuery q(getDatabase());
  const QString sql =
      "SELECT "
      "te.entry_id, "
      "te.section_id, sec.section_name, c.course_name, "
      "te.subject_id, sub.subject_name, "
      "te.teacher_id, t.name, "
      "te.room_id, r.room_name, "
      "te.day, te.slot_index, "
      "CONCAT(DATE_FORMAT(ts.start_time, '%H:%i'), ' - ', "
      "DATE_FORMAT(ts.end_time, '%H:%i')) AS time_range, "
      "sub.subject_type "
      "FROM timetableentry te "
      "JOIN timeslot ts ON te.day = ts.day AND te.slot_index = ts.slot_index "
      "JOIN subject sub ON te.subject_id = sub.subject_id "
      "JOIN section sec ON te.section_id = sec.section_id "
      "JOIN course c ON sec.course_id = c.course_id "
      "JOIN room r ON te.room_id = r.room_id "
      "JOIN teacher t ON te.teacher_id = t.teacher_id "
      "WHERE te.section_id = :section_id "
      "ORDER BY te.day ASC, te.slot_index ASC";

  q.prepare(sql);
  q.bindValue(":section_id", sectionId);

  if (!q.exec()) {
    qWarning() << "getSectionTimetable SQL failed:" << q.lastError().text()
               << "Query:" << sql;
  } else {
    while (q.next()) {
      TimetableEntry entry;
      entry.entryId = q.value(0).toInt();
      entry.sectionId = q.value(1).toInt();
      entry.sectionName = q.value(2).toString();
      entry.courseName = q.value(3).toString();
      entry.subjectId = q.value(4).toInt();
      entry.subjectName = q.value(5).toString();
      entry.teacherId = q.value(6).toInt();
      entry.teacherName = q.value(7).toString();
      entry.roomId = q.value(8).toInt();
      entry.roomName = q.value(9).toString();
      entry.day = q.value(10).toInt();
      entry.slotIndex = q.value(11).toInt();
      entry.timeRange = q.value(12).toString();
      entry.subjectType = q.value(13).toString();
      list.append(entry);
    }
  }
  return list;
}

QList<DatabaseManager::TeacherAssignment>
DatabaseManager::getTeacherAssignments(int teacherId) {
  ensureConnected();
  QList<TeacherAssignment> list;
  QSqlQuery q(getDatabase());
  const QString sql =
      "SELECT sub.subject_name, sec.section_name, c.course_name "
      "FROM sectionsubjectteacher sst "
      "JOIN subject sub ON sst.subject_id = sub.subject_id "
      "JOIN section sec ON sst.section_id = sec.section_id "
      "JOIN course c ON sec.course_id = c.course_id "
      "WHERE sst.teacher_id = :teacher_id "
      "ORDER BY sub.subject_name ASC, sec.section_name ASC";
  q.prepare(sql);
  q.bindValue(":teacher_id", teacherId);
  if (q.exec()) {
    while (q.next()) {
      TeacherAssignment ta;
      ta.subjectName = q.value(0).toString();
      ta.sectionName = q.value(1).toString();
      ta.courseName = q.value(2).toString();
      list.append(ta);
    }
  }
  return list;
}

QList<DatabaseManager::TeachingRequirementRecord>
DatabaseManager::getAllTeachingRequirements() {
  ensureConnected();
  QList<TeachingRequirementRecord> list;
  QSqlQuery q(getDatabase());
  const QString sql =
      "SELECT sst.section_id, sec.section_name, sec.course_id, sec.student_count, "
      "sst.subject_id, sub.subject_name, sub.lectures_per_week, sub.subject_type, "
      "sst.teacher_id, t.name "
      "FROM sectionsubjectteacher sst "
      "JOIN section sec ON sst.section_id = sec.section_id "
      "JOIN subject sub ON sst.subject_id = sub.subject_id "
      "JOIN teacher t ON sst.teacher_id = t.teacher_id "
      "ORDER BY sst.section_id ASC, sst.subject_id ASC";
  if (q.exec(sql)) {
    while (q.next()) {
      TeachingRequirementRecord rec;
      rec.sectionId = q.value(0).toInt();
      rec.sectionName = q.value(1).toString();
      rec.courseId = q.value(2).toInt();
      rec.studentCount = q.value(3).toInt();
      rec.subjectId = q.value(4).toInt();
      rec.subjectName = q.value(5).toString();
      rec.lecturesPerWeek = q.value(6).toInt();
      rec.subjectType = q.value(7).toString();
      rec.teacherId = q.value(8).toInt();
      rec.teacherName = q.value(9).toString();
      list.append(rec);
    }
  } else {
    qWarning() << "getAllTeachingRequirements SQL failed:" << q.lastError().text();
  }
  return list;
}

QList<DatabaseManager::TimetableEntry>
DatabaseManager::getAllTimetableEntries() {
  ensureConnected();
  QList<TimetableEntry> list;
  QSqlQuery q(getDatabase());
  const QString sql =
      "SELECT "
      "te.entry_id, "
      "te.section_id, sec.section_name, c.course_name, "
      "te.subject_id, sub.subject_name, "
      "te.teacher_id, t.name, "
      "te.room_id, r.room_name, "
      "te.day, te.slot_index, "
      "CONCAT(DATE_FORMAT(ts.start_time, '%H:%i'), ' - ', "
      "DATE_FORMAT(ts.end_time, '%H:%i')) AS time_range, "
      "sub.subject_type "
      "FROM timetableentry te "
      "JOIN timeslot ts ON te.day = ts.day AND te.slot_index = ts.slot_index "
      "JOIN subject sub ON te.subject_id = sub.subject_id "
      "JOIN section sec ON te.section_id = sec.section_id "
      "JOIN course c ON sec.course_id = c.course_id "
      "JOIN room r ON te.room_id = r.room_id "
      "JOIN teacher t ON te.teacher_id = t.teacher_id "
      "ORDER BY te.day ASC, te.slot_index ASC, te.section_id ASC";
  if (q.exec(sql)) {
    while (q.next()) {
      TimetableEntry entry;
      entry.entryId = q.value(0).toInt();
      entry.sectionId = q.value(1).toInt();
      entry.sectionName = q.value(2).toString();
      entry.courseName = q.value(3).toString();
      entry.subjectId = q.value(4).toInt();
      entry.subjectName = q.value(5).toString();
      entry.teacherId = q.value(6).toInt();
      entry.teacherName = q.value(7).toString();
      entry.roomId = q.value(8).toInt();
      entry.roomName = q.value(9).toString();
      entry.day = q.value(10).toInt();
      entry.slotIndex = q.value(11).toInt();
      entry.timeRange = q.value(12).toString();
      entry.subjectType = q.value(13).toString();
      list.append(entry);
    }
  } else {
    qWarning() << "getAllTimetableEntries SQL failed:" << q.lastError().text();
  }
  return list;
}

bool DatabaseManager::clearTimetableEntries(QString *errorOut) {
  ensureConnected();
  QSqlDatabase db = getDatabase();
  QSqlQuery q(db);
  if (!q.exec("DELETE FROM timetableentry")) {
    QString err = q.lastError().text();
    if (errorOut) *errorOut = err;
    qWarning() << "clearTimetableEntries failed:" << err;
    return false;
  }
  return true;
}

bool DatabaseManager::saveTimetableEntries(const QList<ScheduledDbEntry> &entries,
                                           bool replaceExisting,
                                           QString *errorOut) {
  ensureConnected();
  if (!isConnected()) {
    if (errorOut) *errorOut = "Database is not connected.";
    return false;
  }

  QSqlDatabase db = getDatabase();

  // Guard against accidental overwrite when replaceExisting is false
  if (!replaceExisting) {
    QSqlQuery checkQ(db);
    if (checkQ.exec("SELECT COUNT(*) FROM timetableentry") && checkQ.next()) {
      int count = checkQ.value(0).toInt();
      if (count > 0) {
        QString msg = QString("Existing timetable contains %1 entries. Set replaceExisting=true to replace.").arg(count);
        if (errorOut) *errorOut = msg;
        return false;
      }
    }
  }

  // Atomic database transaction
  if (!db.transaction()) {
    QString err = "Failed to start database transaction: " + db.lastError().text();
    if (errorOut) *errorOut = err;
    return false;
  }

  // If replacement allowed, safely delete inside the transaction
  if (replaceExisting) {
    QSqlQuery delQ(db);
    if (!delQ.exec("DELETE FROM timetableentry")) {
      QString err = "Failed to clear existing timetable entries: " + delQ.lastError().text();
      db.rollback();
      if (errorOut) *errorOut = err;
      return false;
    }
  }

  // Prepared batch insert
  QSqlQuery insertQ(db);
  insertQ.prepare("INSERT INTO timetableentry (section_id, subject_id, teacher_id, room_id, day, slot_index) "
                  "VALUES (:section_id, :subject_id, :teacher_id, :room_id, :day, :slot_index)");

  for (const auto &e : entries) {
    insertQ.bindValue(":section_id", e.sectionId);
    insertQ.bindValue(":subject_id", e.subjectId);
    insertQ.bindValue(":teacher_id", e.teacherId);
    insertQ.bindValue(":room_id", e.roomId);
    insertQ.bindValue(":day", e.day);
    insertQ.bindValue(":slot_index", e.slotIndex);

    if (!insertQ.exec()) {
      QString err = QString("Insert failed for section=%1, subject=%2, teacher=%3, room=%4, day=%5, slot=%6: %7")
                        .arg(e.sectionId)
                        .arg(e.subjectId)
                        .arg(e.teacherId)
                        .arg(e.roomId)
                        .arg(e.day)
                        .arg(e.slotIndex)
                        .arg(insertQ.lastError().text());
      db.rollback();
      if (errorOut) *errorOut = err;
      qWarning().noquote() << err;
      return false;
    }
  }

  // Commit atomic transaction
  if (!db.commit()) {
    QString err = "Failed to commit database transaction: " + db.lastError().text();
    db.rollback();
    if (errorOut) *errorOut = err;
    return false;
  }

  return true;
}

bool DatabaseManager::testConnection(QString *diagnosticOut) {
  QString report;
  report += "========================================\n";
  report += "   Catalyst Database Diagnostic Test    \n";
  report += "========================================\n";

  QStringList drivers = QSqlDatabase::drivers();
  report += QString("Qt Available SQL Drivers: [%1]\n").arg(drivers.join(", "));

  Config cfg = loadConfig();
  report +=
      QString("Config Host: %1:%2\n").arg(cfg.host, QString::number(cfg.port));
  report += QString("Config Database: %1\n").arg(cfg.databaseName);
  report += QString("Config User: %1\n").arg(cfg.username);
  report += QString("Config Driver Mode: %1\n").arg(cfg.driver);
  if (cfg.driver.compare("QMYSQL", Qt::CaseInsensitive) != 0) {
    report += QString("Config ODBC Driver: %1\n").arg(cfg.odbcDriver);
  }
  report += "----------------------------------------\n";

  QString connectError;
  bool ok = connect(&connectError);

  if (!ok) {
    report += "STATUS: FAILED\n\n";
    report += connectError + "\n";
    report += "========================================\n";
    if (diagnosticOut)
      *diagnosticOut = report;
    qCritical().noquote() << report;
    return false;
  }

  QSqlDatabase db = getDatabase();
  report += QString("STATUS: SUCCESS!\n");
  report += QString("Active Driver: %1\n").arg(db.driverName());

  QSqlQuery q(db);
  if (q.exec("SELECT DATABASE(), VERSION()")) {
    if (q.next()) {
      report += QString("Connected Database: %1\n").arg(q.value(0).toString());
      report +=
          QString("MySQL Server Version: %1\n").arg(q.value(1).toString());
    }
  }

  if (q.exec("SHOW TABLES")) {
    QStringList tables;
    while (q.next()) {
      tables.append(q.value(0).toString());
    }
    report += QString("Found %1 tables: [%2]\n")
                  .arg(QString::number(tables.size()), tables.join(", "));
  }

  if (q.exec("SELECT COUNT(*) FROM timetableentry")) {
    if (q.next()) {
      report += QString("Row count in 'timetableentry': %1\n")
                    .arg(q.value(0).toString());
    }
  }

  // Diagnostic query tests
  QList<TimetableEntry> drRaoDay0 = getFacultyTimetable(1, 0);
  report +=
      QString("Dr. Rao (id=1, day=0): %1 entries\n").arg(drRaoDay0.size());
  for (const auto &e : drRaoDay0) {
    report += QString("   - %1 | %2 | %3 | %4\n")
                  .arg(e.timeRange, e.subjectName, e.sectionName, e.roomName);
  }

  QList<TimetableEntry> drRaoDay1 = getFacultyTimetable(1, 1);
  report +=
      QString("Dr. Rao (id=1, day=1): %1 entries\n").arg(drRaoDay1.size());

  QList<TimetableEntry> msVermaDay0 = getFacultyTimetable(3, 0);
  report +=
      QString("Ms. Verma (id=3, day=0): %1 entries\n").arg(msVermaDay0.size());
  for (const auto &e : msVermaDay0) {
    report += QString("   - %1 | %2 | %3 | %4\n")
                  .arg(e.timeRange, e.subjectName, e.sectionName, e.roomName);
  }

  report += "========================================\n";

  if (diagnosticOut)
    *diagnosticOut = report;
  qInfo().noquote() << report;
  return true;
}

QList<DatabaseManager::Teacher> DatabaseManager::getEligibleTeachersForSubject(int subjectId) {
  ensureConnected();
  QList<Teacher> list;
  QSqlQuery q(getDatabase());
  q.prepare("SELECT t.teacher_id, t.name "
            "FROM teachersubject ts "
            "JOIN teacher t ON ts.teacher_id = t.teacher_id "
            "WHERE ts.subject_id = :subject_id "
            "ORDER BY t.name ASC");
  q.bindValue(":subject_id", subjectId);
  if (q.exec()) {
    while (q.next()) {
      Teacher t;
      t.id = q.value(0).toInt();
      t.name = q.value(1).toString();
      list.append(t);
    }
  } else {
    qWarning() << "getEligibleTeachersForSubject failed:" << q.lastError().text();
  }
  return list;
}

QList<DatabaseManager::Subject> DatabaseManager::getSubjectsForCourse(int courseId) {
  ensureConnected();
  QList<Subject> list;
  QSqlQuery q(getDatabase());
  q.prepare("SELECT s.subject_id, s.subject_name, s.lectures_per_week, s.subject_type "
            "FROM coursesubject cs "
            "JOIN subject s ON cs.subject_id = s.subject_id "
            "WHERE cs.course_id = :course_id "
            "ORDER BY s.subject_name ASC");
  q.bindValue(":course_id", courseId);
  if (q.exec()) {
    while (q.next()) {
      Subject s;
      s.id = q.value(0).toInt();
      s.name = q.value(1).toString();
      s.lecturesPerWeek = q.value(2).toInt();
      s.type = q.value(3).toString();
      list.append(s);
    }
  } else {
    qWarning() << "getSubjectsForCourse failed:" << q.lastError().text();
  }
  if (list.isEmpty()) {
    list = getSubjects();
  }
  return list;
}

QList<DatabaseManager::SectionAssignmentInput> DatabaseManager::getAssignmentsForSection(int sectionId) {
  ensureConnected();
  QList<SectionAssignmentInput> list;
  QSqlQuery q(getDatabase());
  q.prepare("SELECT subject_id, teacher_id "
            "FROM sectionsubjectteacher "
            "WHERE section_id = :section_id "
            "ORDER BY subject_id ASC");
  q.bindValue(":section_id", sectionId);
  if (q.exec()) {
    while (q.next()) {
      SectionAssignmentInput a;
      a.subjectId = q.value(0).toInt();
      a.teacherId = q.value(1).toInt();
      list.append(a);
    }
  } else {
    qWarning() << "getAssignmentsForSection failed:" << q.lastError().text();
  }
  return list;
}

bool DatabaseManager::isTeacherEligibleForSubject(int teacherId, int subjectId) {
  ensureConnected();
  QSqlQuery q(getDatabase());
  q.prepare("SELECT 1 FROM teachersubject WHERE teacher_id = :t_id AND subject_id = :s_id");
  q.bindValue(":t_id", teacherId);
  q.bindValue(":s_id", subjectId);
  if (q.exec() && q.next()) {
    return true;
  }
  return false;
}

bool DatabaseManager::saveSectionWithAssignments(
    int sectionId,
    const QString &sectionName,
    int courseId,
    int studentCount,
    const QList<SectionAssignmentInput> &assignments,
    int *outSectionId,
    QString *errorOut,
    bool *outTimetableInvalidated) {
  ensureConnected();

  if (outTimetableInvalidated) {
    *outTimetableInvalidated = false;
  }

  if (sectionName.trimmed().isEmpty()) {
    if (errorOut) *errorOut = "Section name cannot be empty.";
    return false;
  }
  if (studentCount <= 0) {
    if (errorOut) *errorOut = "Student count must be greater than zero.";
    return false;
  }
  if (courseId <= 0) {
    if (errorOut) *errorOut = "Please select a valid course.";
    return false;
  }
  if (assignments.isEmpty()) {
    if (errorOut) *errorOut = "At least one subject-teacher assignment is required.";
    return false;
  }

  // Check for duplicate subject assignments
  QSet<int> seenSubjects;
  for (const auto &a : assignments) {
    if (a.subjectId <= 0 || a.teacherId <= 0) {
      if (errorOut) *errorOut = "All assignments must have a valid subject and teacher selected.";
      return false;
    }
    if (seenSubjects.contains(a.subjectId)) {
      if (errorOut) *errorOut = QString("Duplicate assignment detected: Subject ID %1 cannot be assigned twice to the same section.").arg(a.subjectId);
      return false;
    }
    seenSubjects.insert(a.subjectId);

    // Verify teacher eligibility via teachersubject
    if (!isTeacherEligibleForSubject(a.teacherId, a.subjectId)) {
      if (errorOut) {
        *errorOut = QString("Teacher ID %1 is not eligible to teach Subject ID %2 according to teachersubject records.")
                        .arg(a.teacherId).arg(a.subjectId);
      }
      return false;
    }
  }

  QSqlDatabase db = getDatabase();
  if (!db.transaction()) {
    if (errorOut) *errorOut = "Failed to start database transaction: " + db.lastError().text();
    return false;
  }

  int targetSectionId = sectionId;

  if (sectionId <= 0) {
    // Check if section name already exists for this course
    QSqlQuery checkQ(db);
    checkQ.prepare("SELECT section_id FROM section WHERE section_name = :name AND course_id = :course_id");
    checkQ.bindValue(":name", sectionName.trimmed());
    checkQ.bindValue(":course_id", courseId);
    if (checkQ.exec() && checkQ.next()) {
      db.rollback();
      if (errorOut) *errorOut = QString("A section named '%1' already exists for this course.").arg(sectionName.trimmed());
      return false;
    }

    // Insert new section
    QSqlQuery insSec(db);
    insSec.prepare("INSERT INTO section (section_name, course_id, student_count) VALUES (:name, :course_id, :count)");
    insSec.bindValue(":name", sectionName.trimmed());
    insSec.bindValue(":course_id", courseId);
    insSec.bindValue(":count", studentCount);
    if (!insSec.exec()) {
      QString err = insSec.lastError().text();
      db.rollback();
      if (errorOut) *errorOut = "Failed to insert section: " + err;
      return false;
    }

    targetSectionId = insSec.lastInsertId().toInt();
    if (targetSectionId <= 0) {
      db.rollback();
      if (errorOut) *errorOut = "Failed to retrieve generated section ID.";
      return false;
    }

    // Insert all assignments for new section
    QSqlQuery insAssign(db);
    insAssign.prepare("INSERT INTO sectionsubjectteacher (section_id, subject_id, teacher_id) "
                      "VALUES (:sec_id, :sub_id, :t_id)");
    for (const auto &a : assignments) {
      insAssign.bindValue(":sec_id", targetSectionId);
      insAssign.bindValue(":sub_id", a.subjectId);
      insAssign.bindValue(":t_id", a.teacherId);
      if (!insAssign.exec()) {
        QString err = insAssign.lastError().text();
        db.rollback();
        if (errorOut) *errorOut = QString("Failed to insert assignment (Subject %1, Teacher %2): %3")
                                      .arg(a.subjectId).arg(a.teacherId).arg(err);
        return false;
      }
    }
  } else {
    // 1. Verify section exists
    QSqlQuery checkSec(db);
    checkSec.prepare("SELECT section_id FROM section WHERE section_id = :id");
    checkSec.bindValue(":id", sectionId);
    if (!checkSec.exec() || !checkSec.next()) {
      db.rollback();
      if (errorOut) *errorOut = QString("Section ID %1 does not exist.").arg(sectionId);
      return false;
    }

    // 2. Check if new section name clashes with ANOTHER section for the same course
    QSqlQuery checkQ(db);
    checkQ.prepare("SELECT section_id FROM section WHERE section_name = :name AND course_id = :course_id AND section_id != :id");
    checkQ.bindValue(":name", sectionName.trimmed());
    checkQ.bindValue(":course_id", courseId);
    checkQ.bindValue(":id", sectionId);
    if (checkQ.exec() && checkQ.next()) {
      db.rollback();
      if (errorOut) *errorOut = QString("A section named '%1' already exists for this course.").arg(sectionName.trimmed());
      return false;
    }

    // 3. Compare existing assignments with newly submitted assignments
    QSqlQuery curAssignQ(db);
    curAssignQ.prepare("SELECT subject_id, teacher_id FROM sectionsubjectteacher WHERE section_id = :sec_id");
    curAssignQ.bindValue(":sec_id", sectionId);
    if (!curAssignQ.exec()) {
      QString err = curAssignQ.lastError().text();
      db.rollback();
      if (errorOut) *errorOut = "Failed to load current assignments: " + err;
      return false;
    }

    QMap<int, int> existingMap; // subjectId -> teacherId
    while (curAssignQ.next()) {
      existingMap[curAssignQ.value(0).toInt()] = curAssignQ.value(1).toInt();
    }

    QMap<int, int> newMap; // subjectId -> teacherId
    for (const auto &a : assignments) {
      newMap[a.subjectId] = a.teacherId;
    }

    QList<int> toRemove;
    QList<int> toUpdate;
    QList<int> toAdd;

    // Identify removals and modified teachers
    for (auto it = existingMap.begin(); it != existingMap.end(); ++it) {
      int subId = it.key();
      int oldTeacher = it.value();
      if (!newMap.contains(subId)) {
        toRemove.append(subId);
      } else if (newMap[subId] != oldTeacher) {
        toUpdate.append(subId);
      }
    }

    // Identify newly added subjects
    for (auto it = newMap.begin(); it != newMap.end(); ++it) {
      int subId = it.key();
      if (!existingMap.contains(subId)) {
        toAdd.append(subId);
      }
    }

    bool assignmentsChanged = (!toRemove.isEmpty() || !toUpdate.isEmpty() || !toAdd.isEmpty());

    // 4. Invalidate timetable for affected section if assignments changed
    if (assignmentsChanged) {
      QSqlQuery countQ(db);
      countQ.prepare("SELECT COUNT(*) FROM timetableentry WHERE section_id = :sec_id");
      countQ.bindValue(":sec_id", sectionId);
      if (countQ.exec() && countQ.next() && countQ.value(0).toInt() > 0) {
        QSqlQuery delTt(db);
        delTt.prepare("DELETE FROM timetableentry WHERE section_id = :sec_id");
        delTt.bindValue(":sec_id", sectionId);
        if (!delTt.exec()) {
          QString err = delTt.lastError().text();
          db.rollback();
          if (errorOut) *errorOut = "Failed to invalidate affected section timetable entries: " + err;
          return false;
        }
        if (outTimetableInvalidated) {
          *outTimetableInvalidated = true;
        }
      }
    }

    // 5. Update section table details
    QSqlQuery updSec(db);
    updSec.prepare("UPDATE section SET section_name = :name, course_id = :course_id, student_count = :count WHERE section_id = :id");
    updSec.bindValue(":name", sectionName.trimmed());
    updSec.bindValue(":course_id", courseId);
    updSec.bindValue(":count", studentCount);
    updSec.bindValue(":id", sectionId);
    if (!updSec.exec()) {
      QString err = updSec.lastError().text();
      db.rollback();
      if (errorOut) *errorOut = "Failed to update section: " + err;
      return false;
    }

    // 6. Selectively update sectionsubjectteacher without deleting unchanged assignments
    if (!toRemove.isEmpty()) {
      QSqlQuery delQ(db);
      delQ.prepare("DELETE FROM sectionsubjectteacher WHERE section_id = :sec_id AND subject_id = :sub_id");
      for (int subId : toRemove) {
        delQ.bindValue(":sec_id", sectionId);
        delQ.bindValue(":sub_id", subId);
        if (!delQ.exec()) {
          QString err = delQ.lastError().text();
          db.rollback();
          if (errorOut) *errorOut = "Failed to remove assignment: " + err;
          return false;
        }
      }
    }

    if (!toUpdate.isEmpty()) {
      QSqlQuery updQ(db);
      updQ.prepare("UPDATE sectionsubjectteacher SET teacher_id = :t_id WHERE section_id = :sec_id AND subject_id = :sub_id");
      for (int subId : toUpdate) {
        updQ.bindValue(":t_id", newMap[subId]);
        updQ.bindValue(":sec_id", sectionId);
        updQ.bindValue(":sub_id", subId);
        if (!updQ.exec()) {
          QString err = updQ.lastError().text();
          db.rollback();
          if (errorOut) *errorOut = "Failed to update assignment: " + err;
          return false;
        }
      }
    }

    if (!toAdd.isEmpty()) {
      QSqlQuery insQ(db);
      insQ.prepare("INSERT INTO sectionsubjectteacher (section_id, subject_id, teacher_id) VALUES (:sec_id, :sub_id, :t_id)");
      for (int subId : toAdd) {
        insQ.bindValue(":sec_id", sectionId);
        insQ.bindValue(":sub_id", subId);
        insQ.bindValue(":t_id", newMap[subId]);
        if (!insQ.exec()) {
          QString err = insQ.lastError().text();
          db.rollback();
          if (errorOut) *errorOut = "Failed to insert assignment: " + err;
          return false;
        }
      }
    }
  }

  if (!db.commit()) {
    QString err = db.lastError().text();
    db.rollback();
    if (errorOut) *errorOut = "Failed to commit section transaction: " + err;
    return false;
  }

  if (outSectionId) {
    *outSectionId = targetSectionId;
  }
  return true;
}

bool DatabaseManager::deleteSection(int sectionId, QString *errorOut) {
  ensureConnected();
  if (sectionId <= 0) return false;

  QSqlDatabase db = getDatabase();
  if (!db.transaction()) {
    if (errorOut) *errorOut = "Failed to start database transaction: " + db.lastError().text();
    return false;
  }

  // 1. Remove from timetableentry
  QSqlQuery q1(db);
  q1.prepare("DELETE FROM timetableentry WHERE section_id = :sec_id");
  q1.bindValue(":sec_id", sectionId);
  if (!q1.exec()) {
    QString err = q1.lastError().text();
    db.rollback();
    if (errorOut) *errorOut = "Failed to remove section timetable entries: " + err;
    return false;
  }

  // 2. Remove from sectionsubjectteacher
  QSqlQuery q2(db);
  q2.prepare("DELETE FROM sectionsubjectteacher WHERE section_id = :sec_id");
  q2.bindValue(":sec_id", sectionId);
  if (!q2.exec()) {
    QString err = q2.lastError().text();
    db.rollback();
    if (errorOut) *errorOut = "Failed to remove section subject teacher assignments: " + err;
    return false;
  }

  // 3. Remove from section
  QSqlQuery q3(db);
  q3.prepare("DELETE FROM section WHERE section_id = :sec_id");
  q3.bindValue(":sec_id", sectionId);
  if (!q3.exec()) {
    QString err = q3.lastError().text();
    db.rollback();
    if (errorOut) *errorOut = "Failed to delete section record: " + err;
    return false;
  }

  if (!db.commit()) {
    QString err = db.lastError().text();
    db.rollback();
    if (errorOut) *errorOut = "Failed to commit delete transaction: " + err;
    return false;
  }

  return true;
}
