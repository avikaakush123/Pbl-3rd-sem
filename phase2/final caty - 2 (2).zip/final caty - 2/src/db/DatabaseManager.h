#ifndef DATABASE_MANAGER_H
#define DATABASE_MANAGER_H

#include <QString>
#include <QStringList>
#include <QList>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

class DatabaseManager {
public:
    struct Config {
        QString driver;       // "auto", "QMYSQL", or "QODBC"
        QString host;         // default: "127.0.0.1"
        int port;             // default: 3306
        QString databaseName; // default: "catalyst_db"
        QString username;     // default: "root"
        QString password;     // default: ""
        QString odbcDriver;   // e.g. "MySQL ODBC 8.0 Unicode Driver"
    };

    struct Teacher {
        int id;
        QString name;
    };

    struct Course {
        int id;
        QString name;
    };

    struct Section {
        int id;
        QString name;
        int courseId;
        QString courseName;
        int studentCount;
    };

    struct Subject {
        int id;
        QString name;
        int lecturesPerWeek;
        QString type;
    };

    struct Room {
        int id;
        QString name;
        int capacity;
        QString type;
    };

    struct Timeslot {
        int id;
        int day;
        int slotIndex;
        QString startTime;
        QString endTime;
        bool isBreak;
    };

    struct TimetableEntry {
        int entryId;
        int sectionId;
        QString sectionName;
        QString courseName;
        int subjectId;
        QString subjectName;
        int teacherId;
        QString teacherName;
        int roomId;
        QString roomName;
        int day;
        int slotIndex;
        QString timeRange;
        QString subjectType;
    };

    struct TeacherAssignment {
        QString subjectName;
        QString sectionName;
        QString courseName;
    };

    struct ScheduledDbEntry {
        int sectionId{0};
        int subjectId{0};
        int teacherId{0};
        int roomId{0};
        int day{0};
        int slotIndex{0};
    };

    struct TeachingRequirementRecord {
        int sectionId{0};
        QString sectionName;
        int courseId{0};
        int studentCount{0};
        int subjectId{0};
        QString subjectName;
        int lecturesPerWeek{0};
        QString subjectType; // "lecture" or "lab"
        int teacherId{0};
        QString teacherName;
    };

    struct SectionAssignmentInput {
        int subjectId{0};
        int teacherId{0};
    };

    static DatabaseManager& instance();

    // Loads configuration from db_config.ini (or environment variables)
    Config loadConfig() const;

    // Connects to the database using the configured driver
    bool connect(QString *errorOut = nullptr);

    // Runs a diagnostic connection test and returns a clear summary report
    bool testConnection(QString *diagnosticOut = nullptr);

    // Checks if the database is open and valid
    bool isConnected() const;

    // Closes the database connection safely
    void close();

    // Access the underlying QSqlDatabase
    QSqlDatabase getDatabase() const;

    // Table Counts
    int getTeacherCount();
    int getSectionCount();
    int getRoomCount();
    int getSubjectCount();
    int getTimeslotCount();
    int getTimetableEntryCount();

    // Entity Queries
    QList<Teacher> getTeachers();
    QList<Course> getCourses();
    QList<Section> getSections();
    QList<Subject> getSubjects();
    QList<Room> getRooms();
    QList<Timeslot> getTimeslots(int day = -1);
    QList<TimetableEntry> getFacultyTimetable(int teacherId, int day = -1);
    QList<TimetableEntry> getSectionTimetable(int sectionId);
    QList<TeacherAssignment> getTeacherAssignments(int teacherId);
    QList<TeachingRequirementRecord> getAllTeachingRequirements();
    QList<TimetableEntry> getAllTimetableEntries();

    // Section & Assignment Management
    QList<Teacher> getEligibleTeachersForSubject(int subjectId);
    QList<Subject> getSubjectsForCourse(int courseId);
    QList<SectionAssignmentInput> getAssignmentsForSection(int sectionId);
    bool isTeacherEligibleForSubject(int teacherId, int subjectId);
    bool saveSectionWithAssignments(int sectionId,
                                    const QString &sectionName,
                                    int courseId,
                                    int studentCount,
                                    const QList<SectionAssignmentInput> &assignments,
                                    int *outSectionId = nullptr,
                                    QString *errorOut = nullptr,
                                    bool *outTimetableInvalidated = nullptr);
    bool deleteSection(int sectionId, QString *errorOut = nullptr);

    // Timetable Persistence & Safe Replacement
    bool saveTimetableEntries(const QList<ScheduledDbEntry> &entries, bool replaceExisting = false, QString *errorOut = nullptr);
    bool clearTimetableEntries(QString *errorOut = nullptr);

    // Connection name used by QSqlDatabase
    static const QString CONNECTION_NAME;

private:
    DatabaseManager();
    ~DatabaseManager();
    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;

    QString resolveOdbcDriver(const QString &configuredDriver) const;
    void ensureConnected();
};

#endif // DATABASE_MANAGER_H
