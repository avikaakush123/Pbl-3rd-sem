#ifndef ADMIN_PORTAL_TESTS_H
#define ADMIN_PORTAL_TESTS_H

#include "AdminPortal.h"
#include "../../db/DatabaseManager.h"
#include "../../scheduler/TimetableService.h"
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace catalyst {

inline bool runAdminPortalTests(std::string *outputReport = nullptr) {
    std::ostringstream out;
    out << "========================================\n";
    out << "   AdminPortal Milestone 4A UI Tests    \n";
    out << "========================================\n";

    int totalTests = 0;
    int passedTests = 0;

    auto assertTest = [&](bool condition, const std::string &testName) {
        totalTests++;
        if (condition) {
            passedTests++;
            out << "[PASS] " << testName << "\n";
        } else {
            out << "[FAIL] " << testName << "\n";
        }
    };

    DatabaseManager &db = DatabaseManager::instance();
    if (!db.isConnected()) {
        db.connect();
    }

    if (!db.isConnected()) {
        out << "[SKIP] Database is not connected. Skipping AdminPortal tests.\n";
        if (outputReport) *outputReport = out.str();
        return false;
    }

    // Save existing seed entries
    QList<DatabaseManager::TimetableEntry> initialEntries = db.getAllTimetableEntries();
    out << "[INFO] Seed timetableentry rows before tests: " << initialEntries.size() << "\n";

    AdminPortal portal;

    // Test 1: Empty timetable table handling & display
    {
        // Temporarily clear to test empty state
        QString err;
        db.clearTimetableEntries(&err);
        portal.refreshData();

        assertTest(db.getTimetableEntryCount() == 0, "Timetable table is empty");

        // Generation when no timetable exists:
        // promptConfirmation=false, confirmReplacement=false.
        // Because count==0, it should NOT require replacement confirmation and should generate directly!
        bool cancelled = false;
        QString msg;
        bool success = portal.generateTimetableAction(false, false, &cancelled, &msg);

        assertTest(!cancelled, "No replacement confirmation requested when table was empty");
        assertTest(success, "Generated and saved timetable from empty state");
        assertTest(db.getTimetableEntryCount() > 0, "Database populated with new generated entries");
    }

    // Test 2: Existing-timetable protection & cancellation
    {
        int countBefore = db.getTimetableEntryCount();
        assertTest(countBefore > 0, "Table contains existing entries before cancellation test");

        // Simulate admin cancelling the replacement dialog (confirmReplacement = false)
        bool cancelled = false;
        QString msg;
        bool success = portal.generateTimetableAction(false /* no GUI modal prompt */, false /* user clicked No */, &cancelled, &msg);

        assertTest(cancelled, "Replacement flagged as cancelled by user");
        assertTest(!success, "Action returned false on cancellation");
        assertTest(db.getTimetableEntryCount() == countBefore, "Database completely unchanged when replacement cancelled (" +
                   std::to_string(countBefore) + " rows preserved)");
    }

    // Test 3: Confirming replacement
    {
        int countBefore = db.getTimetableEntryCount();

        // Simulate admin confirming the replacement dialog (confirmReplacement = true)
        bool cancelled = false;
        QString msg;
        bool success = portal.generateTimetableAction(false, true /* user clicked Yes */, &cancelled, &msg);

        assertTest(!cancelled, "Replacement confirmed");
        assertTest(success, "Generated and replaced timetable successfully");
        assertTest(db.getTimetableEntryCount() > 0, "New timetable exists in database after confirmed replacement");
    }

    // Test 4: Verifying displayed timetable data reflects database
    {
        portal.refreshData();
        QList<DatabaseManager::TimetableEntry> dbEntries = db.getAllTimetableEntries();
        assertTest(!dbEntries.isEmpty(), "Verified live entries retrieved from catalyst_db (" +
                   std::to_string(dbEntries.size()) + " rows)");

        // Check fields of first entry
        const auto &first = dbEntries.first();
        assertTest(!first.sectionName.isEmpty(), "Entry has valid section name: " + first.sectionName.toStdString());
        assertTest(!first.subjectName.isEmpty(), "Entry has valid subject name: " + first.subjectName.toStdString());
        assertTest(!first.teacherName.isEmpty(), "Entry has valid teacher name: " + first.teacherName.toStdString());
        assertTest(!first.roomName.isEmpty(), "Entry has valid room name: " + first.roomName.toStdString());
        assertTest(!first.timeRange.isEmpty(), "Entry has formatted time range: " + first.timeRange.toStdString());
    }

    // Test 5: Section Timetable & Dr. Alan Turing DBMS reflection for CSE-TEST
    {
        QList<DatabaseManager::TimetableEntry> cseTestEntries = db.getSectionTimetable(9);
        assertTest(!cseTestEntries.isEmpty(), "Section 9 (CSE-TEST) has scheduled timetable entries (" +
                   std::to_string(cseTestEntries.size()) + " rows)");

        bool hasTuringDBMS = false;
        bool hasConsecutiveLab = false;
        for (int i = 0; i < cseTestEntries.size(); ++i) {
            const auto &e = cseTestEntries[i];
            if (e.teacherName.contains("Turing", Qt::CaseInsensitive) &&
                e.subjectName.contains("DBMS", Qt::CaseInsensitive)) {
                hasTuringDBMS = true;
            }
            if (e.subjectType.compare("lab", Qt::CaseInsensitive) == 0 && i + 1 < cseTestEntries.size()) {
                const auto &nextE = cseTestEntries[i + 1];
                if (nextE.day == e.day && nextE.slotIndex == e.slotIndex + 1 &&
                    nextE.subjectId == e.subjectId && nextE.teacherId == e.teacherId) {
                    hasConsecutiveLab = true;
                }
            }
        }
        assertTest(hasTuringDBMS, "CSE-TEST displays Dr. Alan Turing's DBMS classes in timetable");
        assertTest(hasConsecutiveLab, "Labs occupy consecutive timeslots for Section 9");
    }

    // Test 6: Automated Section-Subject-Teacher Assignment Management
    {
        // 1 & 2: Create a new test section through the automated API
        QList<DatabaseManager::SectionAssignmentInput> testAssigns;
        // Subject 1 (Data Structures) -> Teacher 1 (Dr. Rao) - eligible in teachersubject
        testAssigns.append({1, 1});
        // Subject 2 (OOP) -> Teacher 3 (Ms. Verma) - eligible in teachersubject
        testAssigns.append({2, 3});

        QString err;
        int autoSecId = -1;
        bool created = db.saveSectionWithAssignments(-1, "AUTO-SEC-TEST", 1, 48, testAssigns, &autoSecId, &err);
        assertTest(created && autoSecId > 0, "Created new section AUTO-SEC-TEST via automated transaction");

        // 3: Verify section and assignments exist in database
        QList<DatabaseManager::SectionAssignmentInput> loadedAssigns = db.getAssignmentsForSection(autoSecId);
        assertTest(loadedAssigns.size() == 2, "Verified 2 assignments automatically inserted into sectionsubjectteacher");

        // 4: Verify that ineligible teacher-subject combination is rejected
        QList<DatabaseManager::SectionAssignmentInput> invalidAssigns;
        // Subject 4 (Operating Systems) -> Teacher 13 (Dr. Alan Turing, only qualified for DBMS in teachersubject)
        invalidAssigns.append({4, 13});
        QString invalidErr;
        int dummyId = -1;
        bool invalidCreated = db.saveSectionWithAssignments(-1, "INVALID-SEC", 1, 40, invalidAssigns, &dummyId, &invalidErr);
        assertTest(!invalidCreated, "Ineligible teacher-subject combination rejected and rolled back: " + invalidErr.toStdString());

        // 5: Edit existing section's assignments
        // Change Subject 1's teacher to Teacher 2 (Prof. Sharma, who is also eligible for Subject 1)
        testAssigns[0].teacherId = 2;
        bool edited = db.saveSectionWithAssignments(autoSecId, "AUTO-SEC-TEST", 1, 50, testAssigns, &autoSecId, &err);
        assertTest(edited, "Edited section assignments successfully");

        QList<DatabaseManager::SectionAssignmentInput> updatedAssigns = db.getAssignmentsForSection(autoSecId);
        assertTest(!updatedAssigns.isEmpty() && updatedAssigns[0].teacherId == 2,
                   "Verified updated teacher assignment (Prof. Sharma) reflected in database");

        // 6 & 7: Cleanup test section
        bool deleted = db.deleteSection(autoSecId, &err);
        assertTest(deleted, "Deleted test section and cleaned up assignments without affecting existing sections");
    }

    // Test 7: Section Editing and Subject-Teacher Assignment Updates (Scenarios 1-10)
    {
        // Setup initial section with 2 valid assignments
        QList<DatabaseManager::SectionAssignmentInput> assigns;
        assigns.append({1, 1}); // Subject 1 (Data Structures) -> Teacher 1 (Dr. Rao)
        assigns.append({2, 3}); // Subject 2 (OOP with C++) -> Teacher 3 (Ms. Verma)

        QString err;
        int testSecId = -1;
        bool ttInvalid = false;

        // Scenario 1: Edit a section with no generated timetable
        bool s1Created = db.saveSectionWithAssignments(-1, "EDIT-TEST-SEC", 1, 45, assigns, &testSecId, &err, &ttInvalid);
        assertTest(s1Created && testSecId > 0 && !ttInvalid, "Scenario 1: Created section with no timetable");

        assigns[0].teacherId = 2; // Change teacher for Subject 1 to Teacher 2 (Prof. Sharma)
        bool s1Edited = db.saveSectionWithAssignments(testSecId, "EDIT-TEST-SEC", 1, 45, assigns, &testSecId, &err, &ttInvalid);
        assertTest(s1Edited && !ttInvalid, "Scenario 1: Edited teacher in section without timetable (no invalidation)");

        // Setup: Add a timetable entry for this test section to test scenarios 2 and 9
        int entriesBeforeTest = db.getTimetableEntryCount();
        QSqlQuery insTestTt(db.getDatabase());
        insTestTt.prepare("INSERT INTO timetableentry (section_id, subject_id, teacher_id, room_id, day, slot_index) "
                          "VALUES (:sec, :sub, :t, :rm, :day, :slot)");
        insTestTt.bindValue(":sec", testSecId);
        insTestTt.bindValue(":sub", 1);
        insTestTt.bindValue(":t", 2);
        insTestTt.bindValue(":rm", 5);
        insTestTt.bindValue(":day", 1);
        insTestTt.bindValue(":slot", 0);
        bool addedDummy = insTestTt.exec();
        assertTest(addedDummy, "Setup: Inserted timetable entry for test section");
        int entriesWithDummy = db.getTimetableEntryCount();
        assertTest(entriesWithDummy == entriesBeforeTest + 1, "Setup: Confirmed timetable entry count incremented");

        // Scenario 2: Change a teacher assignment in a section with an existing timetable
        assigns[0].teacherId = 1; // Change teacher back to Teacher 1
        bool s2Edited = db.saveSectionWithAssignments(testSecId, "EDIT-TEST-SEC", 1, 45, assigns, &testSecId, &err, &ttInvalid);
        assertTest(s2Edited && ttInvalid, "Scenario 2: Changed teacher in section with timetable (invalidated successfully)");

        // Scenario 9: Verify timetable entries belonging to other sections remain untouched
        int entriesAfterS2 = db.getTimetableEntryCount();
        assertTest(entriesAfterS2 == entriesBeforeTest,
                   "Scenario 9: Timetable entries of other sections remained completely untouched");

        // Scenario 3: Add a subject assignment to an existing section
        assigns.append({3, 5}); // Subject 3 (DBMS) -> Teacher 5 (Mr. Iyer, eligible in teachersubject)
        bool s3Added = db.saveSectionWithAssignments(testSecId, "EDIT-TEST-SEC", 1, 45, assigns, &testSecId, &err, &ttInvalid);
        QList<DatabaseManager::SectionAssignmentInput> s3Assigns = db.getAssignmentsForSection(testSecId);
        assertTest(s3Added && s3Assigns.size() == 3, "Scenario 3: Added subject assignment to existing section");

        // Scenario 4: Remove an assignment from a section
        assigns.removeLast(); // Remove Subject 3
        bool s4Removed = db.saveSectionWithAssignments(testSecId, "EDIT-TEST-SEC", 1, 45, assigns, &testSecId, &err, &ttInvalid);
        QList<DatabaseManager::SectionAssignmentInput> s4Assigns = db.getAssignmentsForSection(testSecId);
        assertTest(s4Removed && s4Assigns.size() == 2, "Scenario 4: Removed subject assignment from section");

        // Scenario 5: Edit section details without changing assignments
        bool s5Details = db.saveSectionWithAssignments(testSecId, "EDIT-TEST-RENAMED", 1, 58, assigns, &testSecId, &err, &ttInvalid);
        assertTest(s5Details && !ttInvalid, "Scenario 5: Edited section name & student count without invalidating timetable");

        // Scenario 6: Save without making any changes
        bool s6NoChange = db.saveSectionWithAssignments(testSecId, "EDIT-TEST-RENAMED", 1, 58, assigns, &testSecId, &err, &ttInvalid);
        assertTest(s6NoChange && !ttInvalid, "Scenario 6: Saved unchanged section without modifying timetable");

        // Scenario 7: Attempt an invalid teacher-subject assignment
        QList<DatabaseManager::SectionAssignmentInput> invalidAssigns = assigns;
        invalidAssigns[0].teacherId = 13; // Teacher 13 (Alan Turing) not qualified for Subject 1 in teachersubject
        bool s7Invalid = db.saveSectionWithAssignments(testSecId, "EDIT-TEST-RENAMED", 1, 58, invalidAssigns, &testSecId, &err, &ttInvalid);
        assertTest(!s7Invalid && err.contains("not eligible"), "Scenario 7: Ineligible teacher-subject assignment rejected: " + err.toStdString());

        // Scenario 8: Force a database failure during save and verify rollback
        // Attempt duplicate section name of an existing section in the same course (e.g. 'A')
        bool s8Fail = db.saveSectionWithAssignments(testSecId, "A", 1, 58, assigns, &testSecId, &err, &ttInvalid);
        assertTest(!s8Fail && err.contains("already exists"), "Scenario 8: Name conflict rejected and rolled back cleanly");

        // Cleanup test section
        bool sCleaned = db.deleteSection(testSecId, &err);
        assertTest(sCleaned, "Cleanup: Deleted test section");

        // Scenario 10: Generate a timetable again after editing and verify the updated assignments are reflected
        TimetableService service(db);
        TimetableServiceResult genRes = service.generateAndSaveTimetable(true);
        assertTest(genRes.success && genRes.dbEntriesSaved > 0,
                   "Scenario 10: Timetable generated successfully after section updates");
    }

    // RESTORATION: Restore original seed records
    {
        QList<DatabaseManager::ScheduledDbEntry> restoreList;
        for (const auto &b : initialEntries) {
            DatabaseManager::ScheduledDbEntry e;
            e.sectionId = b.sectionId;
            e.subjectId = b.subjectId;
            e.teacherId = b.teacherId;
            e.roomId = b.roomId;
            e.day = b.day;
            e.slotIndex = b.slotIndex;
            restoreList.append(e);
        }

        QString restoreErr;
        bool restored = db.saveTimetableEntries(restoreList, true, &restoreErr);
        assertTest(restored, "Restored original seed database entries");

        portal.refreshData();
        assertTest(db.getTimetableEntryCount() == initialEntries.size(),
                   "Verified database restored to " + std::to_string(initialEntries.size()) + " original rows");
    }

    out << "----------------------------------------\n";
    out << "SUMMARY: " << passedTests << " / " << totalTests << " AdminPortal tests PASSED.\n";
    out << "========================================\n";

    if (outputReport) {
        *outputReport = out.str();
    }

    return (passedTests == totalTests);
}

} // namespace catalyst

#endif // ADMIN_PORTAL_TESTS_H

