#include "AdminPortal.h"
#include "SectionAssignmentDialog.h"
#include "../../db/DatabaseManager.h"
#include "../../scheduler/TimetableService.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <QFrame>
#include <QPalette>
#include <QFont>
#include <QStringList>
#include <QTabWidget>
#include <QTableWidget>
#include <QHeaderView>
#include <QMessageBox>
#include <QApplication>

AdminPortal::AdminPortal(QWidget *parent)
    : QWidget(parent),
      facultyCountLabel(nullptr),
      sectionCountLabel(nullptr),
      roomCountLabel(nullptr),
      entryCountLabel(nullptr),
      genBtn(nullptr),
      clashBtn(nullptr),
      dataTabs(nullptr),
      masterTimetableTable(nullptr),
      sectionFilterCombo(nullptr),
      sectionTimetableTabWidget(nullptr),
      sectionTimetableStatusLabel(nullptr),
      sectionSelectorCombo(nullptr),
      sectionTimetableGrid(nullptr),
      facultyTable(nullptr),
      sectionTable(nullptr),
      courseTable(nullptr),
      subjectTable(nullptr),
      roomTable(nullptr),
      timeslotTable(nullptr)
{
    setWindowTitle("Catalyst - Admin Portal");
    resize(1150, 760);

    QPalette pagePalette = palette();
    pagePalette.setColor(QPalette::Window, QColor("#F5F7FB"));
    pagePalette.setColor(QPalette::WindowText, QColor("#172B4D"));
    setPalette(pagePalette);
    setAutoFillBackground(true);

    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(28, 20, 28, 20);
    mainLayout->setSpacing(16);

    // Header
    auto *header = new QFrame(this);
    header->setMinimumHeight(76);
    QPalette headerPalette = header->palette();
    headerPalette.setColor(QPalette::Window, QColor("#142B52"));
    header->setPalette(headerPalette);
    header->setAutoFillBackground(true);

    auto *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(20, 12, 20, 12);

    auto *brand = new QLabel("CATALYST | ADMIN PORTAL", header);
    QFont brandFont = brand->font();
    brandFont.setPointSize(16);
    brandFont.setBold(true);
    brand->setFont(brandFont);
    QPalette brandPalette = brand->palette();
    brandPalette.setColor(QPalette::WindowText, Qt::white);
    brand->setPalette(brandPalette);

    auto *backButton = new QPushButton("Back to Welcome", header);
    connect(backButton, &QPushButton::clicked, this, &AdminPortal::backRequested);
    headerLayout->addWidget(brand);
    headerLayout->addStretch();
    headerLayout->addWidget(backButton);
    mainLayout->addWidget(header);

    // Title & description
    auto *heading = new QLabel("Admin Dashboard", this);
    QFont headingFont = heading->font();
    headingFont.setPointSize(22);
    headingFont.setBold(true);
    heading->setFont(headingFont);
    mainLayout->addWidget(heading);

    auto *description = new QLabel("Manage college timetables, faculty, rooms and scheduling conflicts from catalyst_db.", this);
    mainLayout->addWidget(description);

    // Statistics Cards
    auto *statsLayout = new QHBoxLayout;
    statsLayout->setSpacing(16);

    auto createStatCard = [this, statsLayout](const QString &title, QLabel *&labelPtr) {
        auto *card = new QFrame(this);
        card->setFrameShape(QFrame::StyledPanel);
        card->setMinimumHeight(105);
        QPalette cardPalette = card->palette();
        cardPalette.setColor(QPalette::Window, Qt::white);
        card->setPalette(cardPalette);
        card->setAutoFillBackground(true);

        auto *cardLayout = new QVBoxLayout(card);
        cardLayout->setContentsMargins(16, 12, 16, 12);
        labelPtr = new QLabel("0", card);
        QFont valFont = labelPtr->font();
        valFont.setPointSize(23);
        valFont.setBold(true);
        labelPtr->setFont(valFont);

        auto *lbl = new QLabel(title, card);
        cardLayout->addWidget(labelPtr);
        cardLayout->addWidget(lbl);
        cardLayout->addStretch();
        statsLayout->addWidget(card);
    };

    createStatCard("Faculty Members", facultyCountLabel);
    createStatCard("Active Sections", sectionCountLabel);
    createStatCard("Available Rooms", roomCountLabel);
    createStatCard("Scheduled Entries", entryCountLabel);
    mainLayout->addLayout(statsLayout);

    // Quick Actions
    auto *actionsTitle = new QLabel("Quick Actions & Master Records", this);
    QFont actionsFont = actionsTitle->font();
    actionsFont.setPointSize(16);
    actionsFont.setBold(true);
    mainLayout->addWidget(actionsTitle);

    auto *actionsLayout = new QHBoxLayout;
    genBtn = new QPushButton("Generate Timetable", this);
    genBtn->setMinimumHeight(38);
    genBtn->setCursor(Qt::PointingHandCursor);
    genBtn->setStyleSheet("QPushButton { background-color: #2563EB; color: #FFFFFF; font-weight: bold; border-radius: 4px; padding: 6px 16px; }"
                          "QPushButton:hover { background-color: #1D4ED8; }"
                          "QPushButton:disabled { background-color: #94A3B8; color: #E2E8F0; }");

    clashBtn = new QPushButton("Check for Clashes", this);
    clashBtn->setMinimumHeight(38);
    auto *viewTimetableBtn = new QPushButton("View Timetable", this);
    viewTimetableBtn->setMinimumHeight(38);
    auto *manageFacultyBtn = new QPushButton("View Faculty", this);
    manageFacultyBtn->setMinimumHeight(38);
    auto *manageRoomsBtn = new QPushButton("View Rooms", this);
    manageRoomsBtn->setMinimumHeight(38);

    connect(genBtn, &QPushButton::clicked, this, &AdminPortal::onGenerateTimetableClicked);

    connect(clashBtn, &QPushButton::clicked, this, [this]() {
        int entries = DatabaseManager::instance().getTimetableEntryCount();
        if (entries == 0) {
            QMessageBox::information(this, "Clash Detector",
                "No timetable entries currently exist in the database. Generate a timetable first.");
        } else {
            QMessageBox::information(this, "Clash Detector",
                QString("Currently %1 entries exist in timetableentry table. Validated conflict-free by Database Integrity constraints.").arg(entries));
        }
    });

    actionsLayout->addWidget(genBtn);
    actionsLayout->addWidget(clashBtn);
    actionsLayout->addWidget(viewTimetableBtn);
    actionsLayout->addWidget(manageFacultyBtn);
    actionsLayout->addWidget(manageRoomsBtn);
    actionsLayout->addStretch();
    mainLayout->addLayout(actionsLayout);

    // Database Tables Tab Widget
    dataTabs = new QTabWidget(this);
    dataTabs->setStyleSheet(
        "QTabWidget::pane { border: 1px solid #CBD5E1; background: #FFFFFF; }"
        "QTabBar::tab { background: #E2E8F0; color: #1E293B; padding: 7px 16px; margin-right: 2px; font-weight: bold; }"
        "QTabBar::tab:selected { background: #142B52; color: #FFFFFF; }");

    auto setupTable = [](QTableWidget *table) {
        table->setAlternatingRowColors(true);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->verticalHeader()->setVisible(false);
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        table->horizontalHeader()->setMinimumHeight(32);
        table->setStyleSheet("QTableWidget { background: #FFFFFF; gridline-color: #E2E8F0; }");
    };

    // Tab 0: Master Generated Timetable with Section Filter
    auto *timetableTabWidget = new QWidget(this);
    auto *timetableTabLayout = new QVBoxLayout(timetableTabWidget);
    timetableTabLayout->setContentsMargins(12, 12, 12, 12);
    timetableTabLayout->setSpacing(10);

    auto *filterRow = new QHBoxLayout;
    auto *filterLbl = new QLabel("Filter by Section:", timetableTabWidget);
    QFont filterFont = filterLbl->font();
    filterFont.setBold(true);
    filterLbl->setFont(filterFont);

    sectionFilterCombo = new QComboBox(timetableTabWidget);
    sectionFilterCombo->setMinimumWidth(180);
    sectionFilterCombo->setMinimumHeight(32);
    sectionFilterCombo->setStyleSheet(
        "QComboBox { background: #FFFFFF; color: #1E293B; border: 1px solid #CBD5E1; border-radius: 4px; padding: 4px 8px; font-weight: bold; }"
        "QComboBox QAbstractItemView { background: #FFFFFF; color: #1E293B; selection-background-color: #2563EB; selection-color: #FFFFFF; }");
    connect(sectionFilterCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &AdminPortal::onSectionFilterChanged);

    filterRow->addWidget(filterLbl);
    filterRow->addWidget(sectionFilterCombo);
    filterRow->addStretch();
    timetableTabLayout->addLayout(filterRow);

    masterTimetableTable = new QTableWidget(timetableTabWidget);
    setupTable(masterTimetableTable);
    timetableTabLayout->addWidget(masterTimetableTable);

    dataTabs->addTab(timetableTabWidget, "Master Timetable");

    // Tab 1: Section Timetable (Weekly Grid Layout)
    sectionTimetableTabWidget = new QWidget(this);
    auto *secTabLayout = new QVBoxLayout(sectionTimetableTabWidget);
    secTabLayout->setContentsMargins(14, 14, 14, 14);
    secTabLayout->setSpacing(10);

    auto *secHeaderLayout = new QHBoxLayout;
    auto *secHeading = new QLabel("Section Timetable", sectionTimetableTabWidget);
    QFont secHeadingFont = secHeading->font();
    secHeadingFont.setPointSize(14);
    secHeadingFont.setBold(true);
    secHeading->setFont(secHeadingFont);

    auto *secSelectLbl = new QLabel("Select Section:", sectionTimetableTabWidget);
    QFont secSelectFont = secSelectLbl->font();
    secSelectFont.setBold(true);
    secSelectLbl->setFont(secSelectFont);

    sectionSelectorCombo = new QComboBox(sectionTimetableTabWidget);
    sectionSelectorCombo->setMinimumWidth(220);
    sectionSelectorCombo->setMinimumHeight(32);
    sectionSelectorCombo->setStyleSheet(
        "QComboBox { background: #FFFFFF; color: #1E293B; border: 1px solid #CBD5E1; border-radius: 4px; padding: 4px 8px; font-weight: bold; }"
        "QComboBox QAbstractItemView { background: #FFFFFF; color: #1E293B; selection-background-color: #2563EB; selection-color: #FFFFFF; }");
    connect(sectionSelectorCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &AdminPortal::onSectionSelectedChanged);

    secHeaderLayout->addWidget(secHeading);
    secHeaderLayout->addSpacing(20);
    secHeaderLayout->addWidget(secSelectLbl);
    secHeaderLayout->addWidget(sectionSelectorCombo);
    secHeaderLayout->addStretch();
    secTabLayout->addLayout(secHeaderLayout);

    sectionTimetableStatusLabel = new QLabel("Select a section to view its complete weekly schedule.", sectionTimetableTabWidget);
    sectionTimetableStatusLabel->setStyleSheet("color: #475569; font-size: 13px;");
    secTabLayout->addWidget(sectionTimetableStatusLabel);

    sectionTimetableGrid = new QTableWidget(sectionTimetableTabWidget);
    setupTable(sectionTimetableGrid);
    sectionTimetableGrid->setWordWrap(true);
    sectionTimetableGrid->verticalHeader()->setVisible(true);
    sectionTimetableGrid->verticalHeader()->setDefaultSectionSize(72);
    sectionTimetableGrid->verticalHeader()->setStyleSheet("QHeaderView::section { font-weight: bold; background: #F1F5F9; color: #1E293B; border: 1px solid #CBD5E1; padding: 4px; }");
    sectionTimetableGrid->horizontalHeader()->setMinimumHeight(44);
    sectionTimetableGrid->horizontalHeader()->setStyleSheet("QHeaderView::section { font-weight: bold; background: #F8FAFC; color: #0F172A; border: 1px solid #CBD5E1; }");
    secTabLayout->addWidget(sectionTimetableGrid, 1);

    dataTabs->addTab(sectionTimetableTabWidget, "Section Timetable");

    // Master entity tabs
    facultyTable = new QTableWidget(this);
    setupTable(facultyTable);
    dataTabs->addTab(facultyTable, "Faculty (Teachers)");

    // Sections tab with Management Toolbar
    auto *sectionsTabWidget = new QWidget(this);
    auto *sectionsTabLayout = new QVBoxLayout(sectionsTabWidget);
    sectionsTabLayout->setContentsMargins(12, 12, 12, 12);
    sectionsTabLayout->setSpacing(10);

    auto *secBtnLayout = new QHBoxLayout;
    auto *addSecBtn = new QPushButton("➕ Add New Section", sectionsTabWidget);
    addSecBtn->setMinimumHeight(34);
    addSecBtn->setStyleSheet("QPushButton { background-color: #2563EB; color: #FFFFFF; font-weight: bold; border-radius: 4px; padding: 4px 14px; }"
                             "QPushButton:hover { background-color: #1D4ED8; }");
    connect(addSecBtn, &QPushButton::clicked, this, &AdminPortal::onAddSectionClicked);

    auto *editSecBtn = new QPushButton("✏️ Edit Section & Assignments", sectionsTabWidget);
    editSecBtn->setMinimumHeight(34);
    connect(editSecBtn, &QPushButton::clicked, this, &AdminPortal::onEditSectionClicked);

    auto *delSecBtn = new QPushButton("🗑️ Delete Section", sectionsTabWidget);
    delSecBtn->setMinimumHeight(34);
    delSecBtn->setStyleSheet("QPushButton { color: #DC2626; font-weight: bold; }");
    connect(delSecBtn, &QPushButton::clicked, this, &AdminPortal::onDeleteSectionClicked);

    secBtnLayout->addWidget(addSecBtn);
    secBtnLayout->addWidget(editSecBtn);
    secBtnLayout->addWidget(delSecBtn);
    secBtnLayout->addStretch();
    sectionsTabLayout->addLayout(secBtnLayout);

    sectionTable = new QTableWidget(sectionsTabWidget);
    setupTable(sectionTable);
    connect(sectionTable, &QTableWidget::cellDoubleClicked, this, [this](int, int) {
        onEditSectionClicked();
    });
    sectionsTabLayout->addWidget(sectionTable, 1);

    dataTabs->addTab(sectionsTabWidget, "Sections");

    courseTable = new QTableWidget(this);
    setupTable(courseTable);
    dataTabs->addTab(courseTable, "Courses");

    subjectTable = new QTableWidget(this);
    setupTable(subjectTable);
    dataTabs->addTab(subjectTable, "Subjects");

    roomTable = new QTableWidget(this);
    setupTable(roomTable);
    dataTabs->addTab(roomTable, "Rooms");

    timeslotTable = new QTableWidget(this);
    setupTable(timeslotTable);
    dataTabs->addTab(timeslotTable, "Timeslots");

    // Connect top quick action buttons safely using specific widgets
    connect(viewTimetableBtn, &QPushButton::clicked, this, [this, timetableTabWidget]() {
        if (dataTabs && timetableTabWidget) dataTabs->setCurrentWidget(timetableTabWidget);
    });
    connect(manageFacultyBtn, &QPushButton::clicked, this, [this]() {
        if (dataTabs && facultyTable) dataTabs->setCurrentWidget(facultyTable);
    });
    connect(manageRoomsBtn, &QPushButton::clicked, this, [this]() {
        if (dataTabs && roomTable) dataTabs->setCurrentWidget(roomTable);
    });

    mainLayout->addWidget(dataTabs, 1);

    // Load live data from MySQL
    refreshData();
}

void AdminPortal::refreshData() {
    DatabaseManager &db = DatabaseManager::instance();

    if (facultyCountLabel) {
        facultyCountLabel->setText(QString::number(db.getTeacherCount()));
    }
    if (sectionCountLabel) {
        sectionCountLabel->setText(QString::number(db.getSectionCount()));
    }
    if (roomCountLabel) {
        roomCountLabel->setText(QString::number(db.getRoomCount()));
    }
    if (entryCountLabel) {
        entryCountLabel->setText(QString::number(db.getTimetableEntryCount()));
    }

    populateSectionFilterCombo();
    populateMasterTimetableTable();
    populateSectionSelectorCombo();
    populateSectionTimetableGrid();
    populateFacultyTable();
    populateSectionTable();
    populateCourseTable();
    populateSubjectTable();
    populateRoomTable();
    populateTimeslotTable();
}

void AdminPortal::onGenerateTimetableClicked() {
    bool cancelled = false;
    QString message;
    bool ok = generateTimetableAction(true, false, &cancelled, &message);

    if (cancelled) {
        return;
    }

    if (ok) {
        QMessageBox::information(this, "Timetable Generated", message);
    } else {
        QMessageBox::critical(this, "Generation Failed", message);
    }
}

void AdminPortal::onSectionFilterChanged(int) {
    populateMasterTimetableTable();
}

void AdminPortal::onSectionSelectedChanged(int) {
    populateSectionTimetableGrid();
}

void AdminPortal::onAddSectionClicked() {
    SectionAssignmentDialog dlg(this, -1);
    if (dlg.exec() == QDialog::Accepted) {
        refreshData();
        if (sectionSelectorCombo) {
            int newSecId = dlg.getSavedSectionId();
            int idx = sectionSelectorCombo->findData(newSecId);
            if (idx >= 0) {
                sectionSelectorCombo->setCurrentIndex(idx);
            }
        }
    }
}

void AdminPortal::onEditSectionClicked() {
    if (!sectionTable) return;
    int currentRow = sectionTable->currentRow();
    if (currentRow < 0) {
        QMessageBox::information(this, "Select Section", "Please select a section from the table to edit.");
        return;
    }

    auto *idItem = sectionTable->item(currentRow, 0);
    if (!idItem) return;
    int sectionId = idItem->text().toInt();
    if (sectionId <= 0) return;

    SectionAssignmentDialog dlg(this, sectionId);
    if (dlg.exec() == QDialog::Accepted) {
        refreshData();
        if (sectionSelectorCombo) {
            int idx = sectionSelectorCombo->findData(sectionId);
            if (idx >= 0) {
                sectionSelectorCombo->setCurrentIndex(idx);
            }
        }
    }
}

void AdminPortal::onDeleteSectionClicked() {
    if (!sectionTable) return;
    int currentRow = sectionTable->currentRow();
    if (currentRow < 0) {
        QMessageBox::information(this, "Select Section", "Please select a section from the table to delete.");
        return;
    }

    auto *idItem = sectionTable->item(currentRow, 0);
    auto *nameItem = sectionTable->item(currentRow, 1);
    if (!idItem || !nameItem) return;

    int sectionId = idItem->text().toInt();
    QString sectionName = nameItem->text();

    QMessageBox::StandardButton reply = QMessageBox::question(
        this,
        "Delete Section?",
        QString("Are you sure you want to delete section <b>%1</b> (ID: %2)?\n\n"
                "This will permanently remove the section, all its subject-teacher assignments, "
                "and any scheduled timetable entries.")
            .arg(sectionName).arg(sectionId),
        QMessageBox::Yes | QMessageBox::No,
        QMessageBox::No);

    if (reply != QMessageBox::Yes) {
        return;
    }

    QString errorMsg;
    bool ok = DatabaseManager::instance().deleteSection(sectionId, &errorMsg);
    if (!ok) {
        QMessageBox::critical(this, "Delete Failed", "Could not delete section:\n\n" + errorMsg);
        return;
    }

    QMessageBox::information(this, "Section Deleted", QString("Section <b>%1</b> was successfully deleted.").arg(sectionName));
    refreshData();
}

bool AdminPortal::generateTimetableAction(bool promptConfirmation,
                                         bool confirmReplacement,
                                         bool *outCancelled,
                                         QString *outMessage) {
    DatabaseManager &db = DatabaseManager::instance();
    int existingCount = db.getTimetableEntryCount();
    bool replaceExisting = false;

    if (existingCount > 0) {
        if (promptConfirmation) {
            QMessageBox::StandardButton reply = QMessageBox::question(
                this,
                "Replace Existing Timetable?",
                QString("An existing timetable with %1 entries was found in the database.\n\n"
                        "Generating a new timetable will replace all existing entries.\n\n"
                        "Do you want to proceed and replace the existing timetable?")
                    .arg(existingCount),
                QMessageBox::Yes | QMessageBox::No,
                QMessageBox::No);

            if (reply != QMessageBox::Yes) {
                if (outCancelled) *outCancelled = true;
                if (outMessage) *outMessage = "Generation cancelled by administrator. Existing timetable preserved.";
                return false;
            }
            replaceExisting = true;
        } else {
            if (!confirmReplacement) {
                if (outCancelled) *outCancelled = true;
                if (outMessage) *outMessage = "Existing timetable exists and replacement was not confirmed.";
                return false;
            }
            replaceExisting = true;
        }
    }

    // Set UI progress state
    QString oldBtnText = genBtn ? genBtn->text() : "Generate Timetable";
    if (genBtn) {
        genBtn->setEnabled(false);
        genBtn->setText("Generating Timetable...");
    }
    if (clashBtn) clashBtn->setEnabled(false);

    QApplication::setOverrideCursor(Qt::WaitCursor);
    qApp->processEvents();

    catalyst::TimetableService service(db);
    catalyst::GeneratorConfig config;
    config.maxNodes = 200000;
    config.timeLimitMs = 25000;

    catalyst::TimetableServiceResult result = service.generateAndSaveTimetable(replaceExisting, config);

    // Restore UI state
    QApplication::restoreOverrideCursor();
    if (genBtn) {
        genBtn->setEnabled(true);
        genBtn->setText(oldBtnText);
    }
    if (clashBtn) clashBtn->setEnabled(true);

    if (outMessage) {
        *outMessage = QString::fromStdString(result.message);
    }

    // Refresh display
    refreshData();
    if (result.success && dataTabs) {
        dataTabs->setCurrentIndex(0); // View master timetable tab
    }

    return result.success;
}

void AdminPortal::populateSectionFilterCombo() {
    if (!sectionFilterCombo) return;

    int currentSelectedId = sectionFilterCombo->currentData().toInt();
    QSignalBlocker blocker(sectionFilterCombo);
    sectionFilterCombo->clear();
    sectionFilterCombo->addItem("All Sections", -1);

    QList<DatabaseManager::Section> sections = DatabaseManager::instance().getSections();
    int newIndex = 0;
    for (int i = 0; i < sections.size(); ++i) {
        const auto &s = sections[i];
        sectionFilterCombo->addItem(QString("%1 (%2)").arg(s.name, s.courseName), s.id);
        if (s.id == currentSelectedId) {
            newIndex = i + 1;
        }
    }
    sectionFilterCombo->setCurrentIndex(newIndex);
}

void AdminPortal::populateSectionSelectorCombo() {
    if (!sectionSelectorCombo) return;

    int currentSelectedId = sectionSelectorCombo->currentData().toInt();
    QSignalBlocker blocker(sectionSelectorCombo);
    sectionSelectorCombo->clear();

    QList<DatabaseManager::Section> sections = DatabaseManager::instance().getSections();
    int newIndex = 0;
    for (int i = 0; i < sections.size(); ++i) {
        const auto &s = sections[i];
        sectionSelectorCombo->addItem(QString("%1 (%2)").arg(s.name, s.courseName), s.id);
        if (s.id == currentSelectedId) {
            newIndex = i;
        }
    }
    if (!sections.isEmpty()) {
        sectionSelectorCombo->setCurrentIndex(newIndex);
    }
}

void AdminPortal::populateSectionTimetableGrid() {
    if (!sectionTimetableGrid || !sectionSelectorCombo) return;

    sectionTimetableGrid->clearSpans();
    sectionTimetableGrid->clear();

    if (sectionSelectorCombo->count() == 0) {
        sectionTimetableGrid->setRowCount(0);
        sectionTimetableGrid->setColumnCount(0);
        if (sectionTimetableStatusLabel) {
            sectionTimetableStatusLabel->setText("No sections found in database.");
        }
        return;
    }

    int selectedSectionId = sectionSelectorCombo->currentData().toInt();
    QString selectedSectionName = sectionSelectorCombo->currentText();

    DatabaseManager &db = DatabaseManager::instance();
    QList<DatabaseManager::Timeslot> allSlots = db.getTimeslots();

    // Determine unique days and unique slots dynamically from MySQL
    QList<int> uniqueDays;
    QMap<int, QString> dayNameMap;
    static const QStringList defaultDayNames = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

    QMap<int, DatabaseManager::Timeslot> slotInfoByIndex;
    for (const auto &ts : allSlots) {
        if (!uniqueDays.contains(ts.day)) {
            uniqueDays.append(ts.day);
            QString dName = (ts.day >= 0 && ts.day < defaultDayNames.size()) ? defaultDayNames[ts.day] : QString("Day %1").arg(ts.day);
            dayNameMap[ts.day] = dName;
        }
        if (!slotInfoByIndex.contains(ts.slotIndex)) {
            slotInfoByIndex[ts.slotIndex] = ts;
        }
    }
    std::sort(uniqueDays.begin(), uniqueDays.end());
    QList<int> sortedSlotIndices = slotInfoByIndex.keys();
    std::sort(sortedSlotIndices.begin(), sortedSlotIndices.end());

    int rowCount = uniqueDays.size();
    int colCount = sortedSlotIndices.size();

    sectionTimetableGrid->setRowCount(rowCount);
    sectionTimetableGrid->setColumnCount(colCount);

    // Set row (Day) headers
    QStringList vHeaderLabels;
    for (int d : uniqueDays) {
        vHeaderLabels.append(dayNameMap.value(d, QString("Day %1").arg(d)));
    }
    sectionTimetableGrid->setVerticalHeaderLabels(vHeaderLabels);

    // Set column (Timeslot) headers
    QStringList hHeaderLabels;
    for (int sIdx : sortedSlotIndices) {
        const auto &ts = slotInfoByIndex[sIdx];
        QString label = ts.isBreak
            ? QString("Break Period\n%1 - %2").arg(ts.startTime, ts.endTime)
            : QString("Slot %1\n%2 - %3").arg(sIdx + 1).arg(ts.startTime, ts.endTime);
        hHeaderLabels.append(label);
    }
    sectionTimetableGrid->setHorizontalHeaderLabels(hHeaderLabels);

    // Initialize all cells as Free or Lunch Break
    for (int r = 0; r < rowCount; ++r) {
        for (int c = 0; c < colCount; ++c) {
            int sIdx = sortedSlotIndices[c];
            const auto &ts = slotInfoByIndex[sIdx];
            auto *item = new QTableWidgetItem();
            item->setTextAlignment(Qt::AlignCenter);

            if (ts.isBreak) {
                item->setText("Lunch Break");
                item->setForeground(QBrush(QColor("#64748B")));
                item->setBackground(QBrush(QColor("#F1F5F9")));
                QFont f = item->font();
                f.setItalic(true);
                item->setFont(f);
            } else {
                item->setText("Free");
                item->setForeground(QBrush(QColor("#94A3B8")));
                item->setBackground(QBrush(QColor("#FFFFFF")));
            }
            sectionTimetableGrid->setItem(r, c, item);
        }
    }

    // Query live section timetable entries from database
    QList<DatabaseManager::TimetableEntry> entries = db.getSectionTimetable(selectedSectionId);

    if (sectionTimetableStatusLabel) {
        if (entries.isEmpty()) {
            sectionTimetableStatusLabel->setText(
                QString("No timetable entries found for %1. Click 'Generate Timetable' to create a schedule.").arg(selectedSectionName));
        } else {
            sectionTimetableStatusLabel->setText(
                QString("Showing %1 scheduled class periods for %2.").arg(entries.size()).arg(selectedSectionName));
        }
    }

    // Index entries by (day, slotIndex)
    QMap<QPair<int, int>, DatabaseManager::TimetableEntry> entryMap;
    for (const auto &e : entries) {
        entryMap[qMakePair(e.day, e.slotIndex)] = e;
    }

    // Populate occupied cells and merge 2-slot consecutive labs
    for (int r = 0; r < rowCount; ++r) {
        int d = uniqueDays[r];

        for (int c = 0; c < colCount; ++c) {
            int sIdx = sortedSlotIndices[c];
            QPair<int, int> key(d, sIdx);
            if (!entryMap.contains(key)) continue;

            const auto &e = entryMap[key];
            bool isLab = (e.subjectType.compare("lab", Qt::CaseInsensitive) == 0);

            // Check if this slot and the next slot form a 2-consecutive-slot lab
            bool isConsecutiveLab = false;
            if (isLab && (c + 1 < colCount)) {
                int nextSlotIdx = sortedSlotIndices[c + 1];
                QPair<int, int> nextKey(d, nextSlotIdx);
                if (entryMap.contains(nextKey)) {
                    const auto &nextE = entryMap[nextKey];
                    if (nextE.subjectId == e.subjectId &&
                        nextE.teacherId == e.teacherId &&
                        nextE.roomId == e.roomId) {
                        isConsecutiveLab = true;
                    }
                }
            }

            if (isConsecutiveLab) {
                // Visually merge consecutive lab slots
                sectionTimetableGrid->setSpan(r, c, 1, 2);

                auto *labItem = new QTableWidgetItem();
                labItem->setTextAlignment(Qt::AlignCenter);
                labItem->setText(QString("[LAB] %1\n%2  |  %3")
                    .arg(e.subjectName, e.teacherName, e.roomName));
                QFont labFont = labItem->font();
                labFont.setBold(true);
                labItem->setFont(labFont);
                labItem->setForeground(QBrush(QColor("#1E3A8A")));
                labItem->setBackground(QBrush(QColor("#DBEAFE")));
                labItem->setToolTip(QString("Lab: %1\nFaculty: %2\nRoom: %3\nDuration: 2 consecutive hours")
                    .arg(e.subjectName, e.teacherName, e.roomName));

                sectionTimetableGrid->setItem(r, c, labItem);
                c++; // Skip spanned slot
            } else {
                auto *item = new QTableWidgetItem();
                item->setTextAlignment(Qt::AlignCenter);
                item->setText(QString("%1\n%2  |  %3")
                    .arg(e.subjectName, e.teacherName, e.roomName));
                QFont f = item->font();
                f.setBold(true);
                item->setFont(f);
                item->setForeground(QBrush(QColor("#0F172A")));
                item->setBackground(QBrush(QColor("#F8FAFC")));
                item->setToolTip(QString("Subject: %1\nTeacher: %2\nRoom: %3")
                    .arg(e.subjectName, e.teacherName, e.roomName));

                sectionTimetableGrid->setItem(r, c, item);
            }
        }
    }
}

void AdminPortal::populateMasterTimetableTable() {
    if (!masterTimetableTable) return;
    masterTimetableTable->clear();
    masterTimetableTable->setColumnCount(7);
    masterTimetableTable->setHorizontalHeaderLabels({"Day", "Time Window", "Section", "Course", "Subject", "Teacher", "Room"});

    static const QStringList days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

    int filterSectionId = sectionFilterCombo ? sectionFilterCombo->currentData().toInt() : -1;

    QList<DatabaseManager::TimetableEntry> allEntries = DatabaseManager::instance().getAllTimetableEntries();
    QList<DatabaseManager::TimetableEntry> displayEntries;

    for (const auto &e : allEntries) {
        if (filterSectionId < 0 || e.sectionId == filterSectionId) {
            displayEntries.append(e);
        }
    }

    if (displayEntries.isEmpty()) {
        masterTimetableTable->setRowCount(1);
        QString msg = allEntries.isEmpty()
            ? "No timetable entries found in catalyst_db. Click 'Generate Timetable' to create one."
            : "No timetable entries for selected section.";
        masterTimetableTable->setItem(0, 0, new QTableWidgetItem("-"));
        masterTimetableTable->setItem(0, 1, new QTableWidgetItem("-"));
        masterTimetableTable->setItem(0, 2, new QTableWidgetItem(msg));
        masterTimetableTable->setItem(0, 3, new QTableWidgetItem("-"));
        masterTimetableTable->setItem(0, 4, new QTableWidgetItem("-"));
        masterTimetableTable->setItem(0, 5, new QTableWidgetItem("-"));
        masterTimetableTable->setItem(0, 6, new QTableWidgetItem("-"));
        return;
    }

    masterTimetableTable->setRowCount(displayEntries.size());
    for (int i = 0; i < displayEntries.size(); ++i) {
        const auto &e = displayEntries[i];
        QString dayName = (e.day >= 0 && e.day < days.size()) ? days[e.day] : QString("Day %1").arg(e.day);

        masterTimetableTable->setItem(i, 0, new QTableWidgetItem(dayName));
        masterTimetableTable->setItem(i, 1, new QTableWidgetItem(e.timeRange));
        masterTimetableTable->setItem(i, 2, new QTableWidgetItem(e.sectionName));
        masterTimetableTable->setItem(i, 3, new QTableWidgetItem(e.courseName));
        masterTimetableTable->setItem(i, 4, new QTableWidgetItem(e.subjectName));
        masterTimetableTable->setItem(i, 5, new QTableWidgetItem(e.teacherName));
        masterTimetableTable->setItem(i, 6, new QTableWidgetItem(e.roomName));
    }
}

void AdminPortal::populateFacultyTable() {
    if (!facultyTable) return;
    facultyTable->clear();
    facultyTable->setColumnCount(3);
    facultyTable->setHorizontalHeaderLabels({"Teacher ID", "Teacher Name", "Assigned Subjects & Batches"});

    QList<DatabaseManager::Teacher> teachers = DatabaseManager::instance().getTeachers();
    facultyTable->setRowCount(teachers.size());

    for (int i = 0; i < teachers.size(); ++i) {
        const auto &t = teachers[i];
        facultyTable->setItem(i, 0, new QTableWidgetItem(QString::number(t.id)));
        facultyTable->setItem(i, 1, new QTableWidgetItem(t.name));

        QList<DatabaseManager::TeacherAssignment> assigns = DatabaseManager::instance().getTeacherAssignments(t.id);
        QStringList descList;
        for (const auto &a : assigns) {
            descList.append(QString("%1 (%2)").arg(a.subjectName, a.sectionName));
        }
        QString desc = descList.isEmpty() ? "No sections assigned" : descList.join(", ");
        facultyTable->setItem(i, 2, new QTableWidgetItem(desc));
    }
}

void AdminPortal::populateSectionTable() {
    if (!sectionTable) return;
    sectionTable->clear();
    sectionTable->setColumnCount(4);
    sectionTable->setHorizontalHeaderLabels({"Section ID", "Section", "Course", "Student Count"});

    QList<DatabaseManager::Section> sections = DatabaseManager::instance().getSections();
    sectionTable->setRowCount(sections.size());

    for (int i = 0; i < sections.size(); ++i) {
        const auto &s = sections[i];
        sectionTable->setItem(i, 0, new QTableWidgetItem(QString::number(s.id)));
        sectionTable->setItem(i, 1, new QTableWidgetItem(s.name));
        sectionTable->setItem(i, 2, new QTableWidgetItem(s.courseName));
        sectionTable->setItem(i, 3, new QTableWidgetItem(QString::number(s.studentCount)));
    }
}

void AdminPortal::populateCourseTable() {
    if (!courseTable) return;
    courseTable->clear();
    courseTable->setColumnCount(2);
    courseTable->setHorizontalHeaderLabels({"Course ID", "Course Name"});

    QList<DatabaseManager::Course> courses = DatabaseManager::instance().getCourses();
    courseTable->setRowCount(courses.size());

    for (int i = 0; i < courses.size(); ++i) {
        const auto &c = courses[i];
        courseTable->setItem(i, 0, new QTableWidgetItem(QString::number(c.id)));
        courseTable->setItem(i, 1, new QTableWidgetItem(c.name));
    }
}

void AdminPortal::populateSubjectTable() {
    if (!subjectTable) return;
    subjectTable->clear();
    subjectTable->setColumnCount(4);
    subjectTable->setHorizontalHeaderLabels({"Subject ID", "Subject Name", "Lectures/Week", "Type"});

    QList<DatabaseManager::Subject> subjects = DatabaseManager::instance().getSubjects();
    subjectTable->setRowCount(subjects.size());

    for (int i = 0; i < subjects.size(); ++i) {
        const auto &sub = subjects[i];
        subjectTable->setItem(i, 0, new QTableWidgetItem(QString::number(sub.id)));
        subjectTable->setItem(i, 1, new QTableWidgetItem(sub.name));
        subjectTable->setItem(i, 2, new QTableWidgetItem(QString::number(sub.lecturesPerWeek)));
        subjectTable->setItem(i, 3, new QTableWidgetItem(sub.type.toUpper()));
    }
}

void AdminPortal::populateRoomTable() {
    if (!roomTable) return;
    roomTable->clear();
    roomTable->setColumnCount(4);
    roomTable->setHorizontalHeaderLabels({"Room ID", "Room Name", "Capacity", "Type"});

    QList<DatabaseManager::Room> rooms = DatabaseManager::instance().getRooms();
    roomTable->setRowCount(rooms.size());

    for (int i = 0; i < rooms.size(); ++i) {
        const auto &r = rooms[i];
        roomTable->setItem(i, 0, new QTableWidgetItem(QString::number(r.id)));
        roomTable->setItem(i, 1, new QTableWidgetItem(r.name));
        roomTable->setItem(i, 2, new QTableWidgetItem(QString::number(r.capacity)));
        roomTable->setItem(i, 3, new QTableWidgetItem(r.type.toUpper()));
    }
}

void AdminPortal::populateTimeslotTable() {
    if (!timeslotTable) return;
    timeslotTable->clear();
    timeslotTable->setColumnCount(5);
    timeslotTable->setHorizontalHeaderLabels({"Slot ID", "Day", "Slot Index", "Time Window", "Is Break"});

    static const QStringList days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

    QList<DatabaseManager::Timeslot> timeslotList = DatabaseManager::instance().getTimeslots();
    timeslotTable->setRowCount(timeslotList.size());

    for (int i = 0; i < timeslotList.size(); ++i) {
        const auto &ts = timeslotList[i];
        timeslotTable->setItem(i, 0, new QTableWidgetItem(QString::number(ts.id)));

        QString dayName = (ts.day >= 0 && ts.day < days.size()) ? days[ts.day] : QString("Day %1").arg(ts.day);
        timeslotTable->setItem(i, 1, new QTableWidgetItem(dayName));
        timeslotTable->setItem(i, 2, new QTableWidgetItem(QString("Slot %1").arg(ts.slotIndex + 1)));
        timeslotTable->setItem(i, 3, new QTableWidgetItem(QString("%1 - %2").arg(ts.startTime, ts.endTime)));
        timeslotTable->setItem(i, 4, new QTableWidgetItem(ts.isBreak ? "Break Period" : "Class Period"));
    }
}
