#include "SectionAssignmentDialog.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QSpinBox>
#include <QTableWidget>
#include <QHeaderView>
#include <QPushButton>
#include <QMessageBox>
#include <QSet>
#include <QFont>

SectionAssignmentDialog::SectionAssignmentDialog(QWidget *parent, int sectionId)
    : QDialog(parent),
      m_sectionId(sectionId),
      m_savedSectionId(-1),
      nameEdit(nullptr),
      courseCombo(nullptr),
      studentCountSpin(nullptr),
      assignmentsTable(nullptr),
      infoLabel(nullptr),
      saveBtn(nullptr),
      cancelBtn(nullptr)
{
    setWindowTitle(m_sectionId <= 0 ? "Create New Section & Subject-Teacher Assignments"
                                    : "Edit Section & Subject-Teacher Assignments");
    resize(760, 560);
    setModal(true);

    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(24, 20, 24, 20);
    mainLayout->setSpacing(16);

    // Title & Instructions
    auto *titleLabel = new QLabel(m_sectionId <= 0
        ? "Add New Section & Assign Teaching Faculty"
        : "Edit Section Details & Teaching Faculty Assignments", this);
    QFont titleFont = titleLabel->font();
    titleFont.setPointSize(14);
    titleFont.setBold(true);
    titleLabel->setFont(titleFont);
    mainLayout->addWidget(titleLabel);

    infoLabel = new QLabel("Select subjects and eligible faculty for this section. "
                           "Faculty options are automatically filtered by subject qualification from teachersubject.", this);
    infoLabel->setStyleSheet("color: #475569; font-size: 13px;");
    infoLabel->setWordWrap(true);
    mainLayout->addWidget(infoLabel);

    // Form: Section metadata
    auto *formLayout = new QFormLayout;
    formLayout->setSpacing(12);

    nameEdit = new QLineEdit(this);
    nameEdit->setPlaceholderText("e.g. CSE-3A, CSE-TEST, Section C");
    nameEdit->setMinimumHeight(32);
    formLayout->addRow("<b>Section Name:</b>", nameEdit);

    courseCombo = new QComboBox(this);
    courseCombo->setMinimumHeight(32);
    connect(courseCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &SectionAssignmentDialog::onCourseChanged);
    formLayout->addRow("<b>Course Curriculum:</b>", courseCombo);

    studentCountSpin = new QSpinBox(this);
    studentCountSpin->setMinimumHeight(32);
    studentCountSpin->setRange(1, 300);
    studentCountSpin->setValue(60);
    formLayout->addRow("<b>Student Capacity:</b>", studentCountSpin);

    mainLayout->addLayout(formLayout);

    // Assignments Table
    auto *tableHeading = new QLabel("Subject Assignments & Faculty Selection:", this);
    QFont thFont = tableHeading->font();
    thFont.setBold(true);
    tableHeading->setFont(thFont);
    mainLayout->addWidget(tableHeading);

    assignmentsTable = new QTableWidget(this);
    assignmentsTable->setColumnCount(5);
    assignmentsTable->setHorizontalHeaderLabels({"Assign", "Subject Name", "Type", "Hrs/Wk", "Eligible Faculty (teachersubject)"});
    assignmentsTable->setAlternatingRowColors(true);
    assignmentsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    assignmentsTable->verticalHeader()->setVisible(false);
    assignmentsTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    assignmentsTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    assignmentsTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    assignmentsTable->horizontalHeader()->setSectionResizeMode(3, QHeaderView::ResizeToContents);
    assignmentsTable->horizontalHeader()->setSectionResizeMode(4, QHeaderView::Stretch);
    assignmentsTable->horizontalHeader()->setMinimumHeight(36);
    assignmentsTable->setStyleSheet("QTableWidget { background: #FFFFFF; gridline-color: #E2E8F0; }"
                                   "QHeaderView::section { font-weight: bold; background: #F8FAFC; color: #1E293B; border: 1px solid #CBD5E1; padding: 4px; }");
    mainLayout->addWidget(assignmentsTable, 1);

    // Dialog buttons
    auto *btnLayout = new QHBoxLayout;
    btnLayout->addStretch();

    cancelBtn = new QPushButton("Cancel", this);
    cancelBtn->setMinimumHeight(36);
    cancelBtn->setMinimumWidth(100);
    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject);

    saveBtn = new QPushButton("Save Section & Assignments", this);
    saveBtn->setMinimumHeight(36);
    saveBtn->setMinimumWidth(210);
    saveBtn->setCursor(Qt::PointingHandCursor);
    saveBtn->setStyleSheet("QPushButton { background-color: #2563EB; color: #FFFFFF; font-weight: bold; border-radius: 4px; padding: 6px 16px; }"
                          "QPushButton:hover { background-color: #1D4ED8; }"
                          "QPushButton:disabled { background-color: #94A3B8; }");
    connect(saveBtn, &QPushButton::clicked, this, &SectionAssignmentDialog::onSaveClicked);

    btnLayout->addWidget(cancelBtn);
    btnLayout->addWidget(saveBtn);
    mainLayout->addLayout(btnLayout);

    // Populate data
    populateCourseCombo();

    if (m_sectionId > 0) {
        loadExistingSectionData();
    } else {
        if (courseCombo->count() > 0) {
            onCourseChanged(courseCombo->currentIndex());
        }
    }
}

void SectionAssignmentDialog::populateCourseCombo() {
    QSignalBlocker blocker(courseCombo);
    courseCombo->clear();
    QList<DatabaseManager::Course> courses = DatabaseManager::instance().getCourses();
    for (const auto &c : courses) {
        courseCombo->addItem(c.name, c.id);
    }
}

void SectionAssignmentDialog::loadExistingSectionData() {
    DatabaseManager &db = DatabaseManager::instance();
    QList<DatabaseManager::Section> sections = db.getSections();

    DatabaseManager::Section curSection;
    bool found = false;
    for (const auto &s : sections) {
        if (s.id == m_sectionId) {
            curSection = s;
            found = true;
            break;
        }
    }

    if (!found) return;

    nameEdit->setText(curSection.name);
    studentCountSpin->setValue(curSection.studentCount);

    int courseIdx = courseCombo->findData(curSection.courseId);
    if (courseIdx >= 0) {
        QSignalBlocker blocker(courseCombo);
        courseCombo->setCurrentIndex(courseIdx);
    }

    // Load existing assignments: map subjectId -> teacherId
    QList<DatabaseManager::SectionAssignmentInput> existingAssigns = db.getAssignmentsForSection(m_sectionId);
    QMap<int, int> preselectedTeachers;
    for (const auto &a : existingAssigns) {
        preselectedTeachers[a.subjectId] = a.teacherId;
    }

    loadSubjectsAndTeachers(curSection.courseId, preselectedTeachers);
}

void SectionAssignmentDialog::onCourseChanged(int index) {
    if (index < 0) return;
    int courseId = courseCombo->currentData().toInt();
    loadSubjectsAndTeachers(courseId);
}

void SectionAssignmentDialog::loadSubjectsAndTeachers(int courseId, const QMap<int, int> &preselectedTeachers) {
    DatabaseManager &db = DatabaseManager::instance();
    QList<DatabaseManager::Subject> subjects = db.getSubjectsForCourse(courseId);

    assignmentsTable->setRowCount(0);
    assignmentsTable->setRowCount(subjects.size());

    for (int i = 0; i < subjects.size(); ++i) {
        const auto &sub = subjects[i];

        // 0: Checkbox
        auto *chkItem = new QTableWidgetItem();
        chkItem->setFlags(Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
        bool shouldCheck = preselectedTeachers.isEmpty() ? true : preselectedTeachers.contains(sub.id);
        chkItem->setCheckState(shouldCheck ? Qt::Checked : Qt::Unchecked);
        assignmentsTable->setItem(i, 0, chkItem);

        // 1: Subject Name (store subjectId in UserRole)
        auto *nameItem = new QTableWidgetItem(sub.name);
        nameItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
        nameItem->setData(Qt::UserRole, sub.id);
        assignmentsTable->setItem(i, 1, nameItem);

        // 2: Type
        auto *typeItem = new QTableWidgetItem(sub.type.toUpper());
        typeItem->setFlags(Qt::ItemIsEnabled);
        typeItem->setTextAlignment(Qt::AlignCenter);
        assignmentsTable->setItem(i, 2, typeItem);

        // 3: Lectures per week
        auto *lecItem = new QTableWidgetItem(QString::number(sub.lecturesPerWeek));
        lecItem->setFlags(Qt::ItemIsEnabled);
        lecItem->setTextAlignment(Qt::AlignCenter);
        assignmentsTable->setItem(i, 3, lecItem);

        // 4: Eligible Teachers Combobox
        auto *tCombo = new QComboBox(assignmentsTable);
        tCombo->setStyleSheet("QComboBox { background: #FFFFFF; color: #1E293B; border: 1px solid #CBD5E1; border-radius: 4px; padding: 4px 8px; font-weight: bold; }");

        QList<DatabaseManager::Teacher> eligibleTeachers = db.getEligibleTeachersForSubject(sub.id);
        tCombo->addItem("-- Select Eligible Faculty --", 0);

        int targetTeacherId = preselectedTeachers.value(sub.id, 0);
        int selectIdx = 0;

        for (int k = 0; k < eligibleTeachers.size(); ++k) {
            const auto &t = eligibleTeachers[k];
            tCombo->addItem(t.name, t.id);
            if (t.id == targetTeacherId) {
                selectIdx = k + 1;
            }
        }

        if (eligibleTeachers.isEmpty()) {
            tCombo->setItemText(0, "-- No Eligible Faculty in teachersubject --");
            tCombo->setEnabled(false);
        } else {
            tCombo->setCurrentIndex(selectIdx);
        }

        assignmentsTable->setCellWidget(i, 4, tCombo);
    }
}

void SectionAssignmentDialog::onSaveClicked() {
    QString sectionName = nameEdit->text().trimmed();
    if (sectionName.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", "Section name cannot be empty. Please enter a valid name.");
        nameEdit->setFocus();
        return;
    }

    int courseId = courseCombo->currentData().toInt();
    if (courseId <= 0) {
        QMessageBox::warning(this, "Validation Error", "Please select a valid course curriculum.");
        courseCombo->setFocus();
        return;
    }

    int studentCount = studentCountSpin->value();
    if (studentCount <= 0) {
        QMessageBox::warning(this, "Validation Error", "Student count must be greater than zero.");
        studentCountSpin->setFocus();
        return;
    }

    QList<DatabaseManager::SectionAssignmentInput> assignments;
    QSet<int> seenSubjects;

    for (int r = 0; r < assignmentsTable->rowCount(); ++r) {
        auto *chkItem = assignmentsTable->item(r, 0);
        if (!chkItem || chkItem->checkState() != Qt::Checked) {
            continue; // Not included
        }

        auto *nameItem = assignmentsTable->item(r, 1);
        if (!nameItem) continue;

        int subjectId = nameItem->data(Qt::UserRole).toInt();
        QString subjectName = nameItem->text();

        auto *tCombo = qobject_cast<QComboBox*>(assignmentsTable->cellWidget(r, 4));
        if (!tCombo) continue;

        int teacherId = tCombo->currentData().toInt();
        if (teacherId <= 0) {
            QMessageBox::warning(this, "Validation Error",
                QString("Please select an assigned faculty member for <b>%1</b>.").arg(subjectName));
            tCombo->setFocus();
            return;
        }

        if (seenSubjects.contains(subjectId)) {
            QMessageBox::warning(this, "Validation Error",
                QString("Duplicate assignment: Subject '%1' is assigned more than once.").arg(subjectName));
            return;
        }
        seenSubjects.insert(subjectId);

        DatabaseManager::SectionAssignmentInput assign;
        assign.subjectId = subjectId;
        assign.teacherId = teacherId;
        assignments.append(assign);
    }

    if (assignments.isEmpty()) {
        QMessageBox::warning(this, "Validation Error",
            "Please assign at least one subject and faculty member to this section.");
        return;
    }

    DatabaseManager &db = DatabaseManager::instance();
    QString errorMsg;
    int savedId = -1;
    bool timetableInvalidated = false;

    bool ok = db.saveSectionWithAssignments(m_sectionId, sectionName, courseId, studentCount,
                                           assignments, &savedId, &errorMsg, &timetableInvalidated);

    if (!ok) {
        QMessageBox::critical(this, "Save Failed",
            QString("Could not save section and assignments:\n\n%1").arg(errorMsg));
        return;
    }

    m_savedSectionId = savedId;
    m_timetableInvalidated = timetableInvalidated;

    if (timetableInvalidated) {
        QMessageBox::warning(this, "Section Saved — Timetable Invalidated",
            QString("Section <b>%1</b> and its <b>%2</b> subject-teacher assignments were saved successfully to catalyst_db.<br><br>"
                    "<b>Note:</b> The previously generated timetable for section <b>%1</b> was invalidated because subject-teacher assignments changed.<br><br>"
                    "The section timetable needs to be regenerated.").arg(sectionName).arg(assignments.size()));
    } else {
        QMessageBox::information(this, "Section Saved",
            QString("Section <b>%1</b> and its <b>%2</b> subject-teacher assignments were saved successfully to catalyst_db.")
                .arg(sectionName).arg(assignments.size()));
    }
    accept();
}

