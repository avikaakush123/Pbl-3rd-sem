#ifndef ADMIN_PORTAL_H
#define ADMIN_PORTAL_H

#include <QWidget>

class QLabel;
class QPushButton;
class QComboBox;
class QTabWidget;
class QTableWidget;

class AdminPortal : public QWidget
{
    Q_OBJECT

public:
    explicit AdminPortal(QWidget *parent = nullptr);

    // Refresh data from the database
    void refreshData();

    // Core generate timetable workflow with confirmation and service execution
    bool generateTimetableAction(bool promptConfirmation = true,
                                 bool confirmReplacement = false,
                                 bool *outCancelled = nullptr,
                                 QString *outMessage = nullptr);

signals:
    void backRequested();

private slots:
    void onGenerateTimetableClicked();
    void onSectionFilterChanged(int index);
    void onSectionSelectedChanged(int index);
    void onAddSectionClicked();
    void onEditSectionClicked();
    void onDeleteSectionClicked();

private:
    QLabel *facultyCountLabel;
    QLabel *sectionCountLabel;
    QLabel *roomCountLabel;
    QLabel *entryCountLabel;

    QPushButton *genBtn;
    QPushButton *clashBtn;

    QTabWidget *dataTabs;
    QTableWidget *masterTimetableTable;
    QComboBox *sectionFilterCombo;

    QWidget *sectionTimetableTabWidget;
    QLabel *sectionTimetableStatusLabel;
    QComboBox *sectionSelectorCombo;
    QTableWidget *sectionTimetableGrid;

    QTableWidget *facultyTable;
    QTableWidget *sectionTable;
    QTableWidget *courseTable;
    QTableWidget *subjectTable;
    QTableWidget *roomTable;
    QTableWidget *timeslotTable;

    void populateMasterTimetableTable();
    void populateSectionFilterCombo();
    void populateSectionSelectorCombo();
    void populateSectionTimetableGrid();
    void populateFacultyTable();
    void populateSectionTable();
    void populateCourseTable();
    void populateSubjectTable();
    void populateRoomTable();
    void populateTimeslotTable();
};

#endif // ADMIN_PORTAL_H
