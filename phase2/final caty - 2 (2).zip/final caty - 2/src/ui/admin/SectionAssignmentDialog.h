#ifndef SECTION_ASSIGNMENT_DIALOG_H
#define SECTION_ASSIGNMENT_DIALOG_H

#include <QDialog>
#include <QList>
#include "../../db/DatabaseManager.h"

class QLineEdit;
class QComboBox;
class QSpinBox;
class QTableWidget;
class QPushButton;
class QLabel;

class SectionAssignmentDialog : public QDialog {
    Q_OBJECT

public:
    explicit SectionAssignmentDialog(QWidget *parent = nullptr, int sectionId = -1);

    int getSavedSectionId() const noexcept { return m_savedSectionId; }
    bool wasTimetableInvalidated() const noexcept { return m_timetableInvalidated; }

private slots:
    void onCourseChanged(int index);
    void onSaveClicked();

private:
    int m_sectionId;
    int m_savedSectionId;
    bool m_timetableInvalidated{false};

    QLineEdit *nameEdit;
    QComboBox *courseCombo;
    QSpinBox *studentCountSpin;
    QTableWidget *assignmentsTable;
    QLabel *infoLabel;
    QPushButton *saveBtn;
    QPushButton *cancelBtn;

    void populateCourseCombo();
    void loadExistingSectionData();
    void loadSubjectsAndTeachers(int courseId, const QMap<int, int> &preselectedTeachers = {});
};

#endif // SECTION_ASSIGNMENT_DIALOG_H

