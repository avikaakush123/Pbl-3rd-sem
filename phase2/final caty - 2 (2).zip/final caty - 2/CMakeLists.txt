
cmake_minimum_required(VERSION 3.21)

project(Catalyst LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

set(CMAKE_AUTOMOC ON)
set(CMAKE_PREFIX_PATH "D:/qt/6.12.0/mingw_64")

find_package(Qt6 REQUIRED COMPONENTS Widgets Sql)

add_executable(Catalyst
    src/main.cpp

    src/db/DatabaseManager.h
    src/db/DatabaseManager.cpp

    src/scheduler/SchedulingModels.h
    src/scheduler/ConflictValidator.h
    src/scheduler/ConflictValidator.cpp
    src/scheduler/ConflictValidatorTests.h
    src/scheduler/TimetableGenerator.h
    src/scheduler/TimetableGenerator.cpp
    src/scheduler/TimetableGeneratorTests.h
    src/scheduler/TimetableService.h
    src/scheduler/TimetableService.cpp
    src/scheduler/TimetableServiceTests.h

    src/ui/WelcomePage.h
    src/ui/WelcomePage.cpp

    src/ui/AuthWindow.h
    src/ui/AuthWindow.cpp

    src/ui/admin/AdminPortal.h
    src/ui/admin/AdminPortal.cpp
    src/ui/admin/AdminPortalTests.h
    src/ui/admin/SectionAssignmentDialog.h
    src/ui/admin/SectionAssignmentDialog.cpp

    src/ui/faculty/FacultyPortal.h
    src/ui/faculty/FacultyPortal.cpp
)

target_link_libraries(Catalyst PRIVATE Qt6::Widgets Qt6::Sql)
